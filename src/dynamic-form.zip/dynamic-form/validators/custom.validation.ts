import { AbstractControl, ValidatorFn, Validators, ValidationErrors, AsyncValidatorFn, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { SharedurlService } from '../../../shared/sharedurl.service';

@Injectable({
  providedIn: 'root'
})
export class CustomValidation {

  //Built-in validators
  ValidatorList = {
    'min': Validators.min,
    'max': Validators.max,
    'maxlength': Validators.maxLength,
    'minlength': Validators.minLength,
    'required': Validators.required,
    'email': Validators.email,
    'pattern': Validators.pattern
  };

  constructor(private http: HttpClient, private sharedUrlService: SharedurlService) {
    //Add custom validators here
    this.ValidatorList['phoneValidator'] = this.phoneValidator.bind(this);
    this.ValidatorList['emailValidator'] = this.emailValidator.bind(this);
    this.ValidatorList['dunsValidator'] = this.dunsValidator.bind(this);
    this.ValidatorList['einValidator'] = this.einValidator.bind(this);
    this.ValidatorList['vatValidator'] = this.vatValidator.bind(this);
    this.ValidatorList['addressValidator'] = this.addressValidator.bind(this);
    this.ValidatorList['optionRequired'] = this.optionRequired.bind(this);
  }

  t: string = 'VdZG9Nd+CMJA6UVBAxPSE5eFdNt3lfJc6CkbmWs1m21CWxlkyCkTkp0*2YbP*U3GnCkleiL8NMI0LpHBA5DUkxk0anL**QNz1l2K9Q60H06mun5+0pmWR9QI+K5S9GiDVlrT3Xcg7fCx*ISjcM0GgVwGFjFsRuHv9EIj4rkWH*LbTYuY207eOkQq1geiwgZpbiFKrRUVsOFwuBQwaYNF7Vs0AcI+2FuNOqVOnVpSe6c*wjsN9xSYZsKIWfOVAmDYBIMeYaep93yeE*KNhDuG3zrvC2dud0nd*fxpDPTjtWV9z*LVf5rp+x79hMzqNw*gCUH8AYKVFdKIQlCYbzXuPhALgMEhRIjaYlj8YPPg3BEY3nt72VhhNLpwz4R6ZtAoMvi3eNN62KFA5Z1cLf*rgo+FBhW7sG*p5HjcmP+CCVBW0C9wYakUMt4VTlxXDi5ZU9IuS6khGYFmLZoWGe+EDQfFoqs2AqnMvFTPssc1ZqJU4FjBXI*KNw+COJyGkQyDmiZF4kSwPqblqR8fzOW+FljomUz5Xlj*hjUHUIzRwka0Xln+JgNlz*0PambysSeCtfbF41qSpl+qVK8gmoPc0+VqOY66ECRO2dnvblMs4apAvCVd9rfg9iwr4N28JVEcO+b99QZ*XVYih+Cym*euk6veBlL8QP*+ECxOZ*LPsjBK5obZnxdtCueeU5d7bAGtsQz6zDQwF3yG*fdwkU4xrJ6DXByEuoU4wLBl5PPA*f3TvB4s9qWtw5tL8pbHqCZ5kj3Dg3XEet1CPbxXKawIbwpMl5XRWCd11DI6q7oKRdcuK6dK9CESGbV9o5fn*CDa27pCbtILRforjxpt2nJbjKqgfU5U+agfXIzzqQlVFZaGqNyMy8RTHuCBSqlx98Kcrz8VGk*Ca4LRE3hy9PSO4X1cqkZbNbZxGV4JSMQH6pAWE7B3zE90CIRXPoHlEWldyWLcdxOySHw8cvYk8R8S*+p+v*cyQhqfArGxRMkqtEyjGqffhdsvjfqnO5Es29O16h89ouT8JISCyuruyfRs6CqWtngF58+Ao3pzJWrus*i1UFMX7SXNsnr6qt2ifdLkViRBI+EMCD43E2KYIU8xtiRNkJd4t7Y0bkI4CrRdOQWkr9IJ4NgQzkP4L6Z*a2KlCVP5ia7wIgEUN3zQl7ImnBlc7bgREBmeFThwEhKeEVz6SEaC2JwzdjpQBTODZbrEG+lPLd4uU5Dc4DCdvQIYFvhK7i06Mu*+7gYVuuxc1b5tgicCXqFMbhk4fQefxQ3I+6qnTpfDq+fg*mo11yijG2BOnD3NJbtPcxtByZnFiwmqHzeUGs+Ta3LzJB6iqc9MAAy+eGSrwVLbV5cLMr+UjW97MHheHDmX3P7kX*SFfoIeekxmS2LgiCVmDH2RiVcMHIPH2+DqeJpb1FTgWhWvZ9bv+aPCA9I98Bwn15B0pCzeZa1xrSbtSYYl1dOXKFoyMnSh9d2+lG2uvPjocWN9IDEO89Swqdf0PzaanuKQdo5nQ7LCLWM47wWy7SP1gmy7NOwNo8Oa54K3aE+cpaJiEnKjPjBhJBjVQZzfp7Ne*UtURlIhZCF3l*FY9uNINvhdyxXMgiI3N5UqOQFwWQ7QQhEygSu55oO38BMX7qD38r0Y4Ji2iKjeQgsasj9BURKkKBA7bxSbszTJfO8rGYsOu7Fnz1SklOSrPkpjVIqOFVDm8HUT40PZycDkIf7BBSGp6CWDYOXspc8RQnwQLIuDX0fZ*AvqO9UffycnC757h+OWPFF1E1vhQ+2wu96nZbAxnCCJHTlGPGqlAIaags78iYbOyHdis52mAyGxWb7KA2rUltF7RrFwskJvr++4eLTvX2KVFATmNRPykEnjFOEM7*XTzlzfGCIloS*8Y+1p*ShuW6eByAaOSZ9LX4S+g9*GvsFJyy0R2TK+OQn6eSJX658qGcYMmBcS+JOQLpPXMvyYMRCwbXdbbRX6LrarrJsWdyWYyZnFooGGJWs06wwYPz5yus4CYiP3fIVJu5TvofrIr5sX5H8CZDxKjqhbudFSdGEwzTro5uIaF63ENQg3eyrP4DO6uYjEPOUQyy79DwmOOzJl3rYz5Yk*Rw18oGm+g4MSrO3bSaV5C8dLWei*90QH4GSKjRGoFiDygpPmAyB+G1NIhgd*8dJ3gGzrQP8U3slVk2U+770pfOaby4ZgeYcchzDhiZFVkC2uwZ1*m28yVcvmbsmWt*Ur+nVQTKH8qcMtaNSJHqK79LGIQpfl4*vpyR8IrCRNPrjvV7rfdGIFDvMQwgWDm73An5hwjj9Jr9ErJoFSw7kHH8FFs2KPEV5rLcsEhXWpKnxjcORMwZZQRHKm5xUUej8WuWZlBNPCqaM5dR9u3se33T0PGKuOPpESL5jCWiI+ZNSN5O93K+d9FKNvg6UH4FA9m0WvvQVYoypTOFhyXtnTfN+JB0cVosutomkzKywDHZkNpTfrhiBzAsZ+nVos*g8yHGHQjpJlZhqPYooDkw*rNHM2DP7OUp8JkS4qmVroGrbF6mE2ageTtkIcY0dPYNZt9Yl+04SWFSh8mS4gcoLaJ6aCSILxLvmNmdqW5r2WwQfd5EoeItR8fGmxk4fEZ9KNDIJkhKvL4Pr7+GjhrdEcwTia8Z4pQpIqBgVaGTBWF5KjqLsE3c3cZjibs2*H7cyPt00CZcZOcmXzn2Fzqzy9jeO**G*MywIQYoC6oMs8VPXvLi*X5yrquWtlXKzLyDrWT1axrVNmLLYplaCg2okKRALFtMc4EEOLOjuCTT1Oa42oDUcmUe1SIrBUL9Y5WibyJGOJqIXdc7PGA1DD5j2v98BVyci9WPgTopIuwLdTuKvG6s8ndEkUF83GktooNPcE1ux5wW85z4tALayzJ1ArJ7ZgSRknUC8*VH9Py2CTF1QDyCn1sOPEBaSGNtBzKCJWZiPprXWARcEvyVyMdP*clkBNpbbmN+gShbXXhcWaeEPKfbhJwiYDibF2AXP4Y9n9m07M6kM3SoeW1oREgMHQJZCJVb1rXkk14Q2I8zAv9o8z3DnGALTFEXWFc8sHzvcoOTOtx4cX7nF2k7KVPD46FYs0NxcAZjAGAMaQFuinVdbdRn7ECVGKzU4kqBos7EYTBwhM+D6I4QvCUhP9ZsNZcSXOQQn*dVEmOcbcjjZkbGdKNh5oZO+OmXtm47mxqoNKpva+*6tIKSn8M+RbaBLMhf8eCNmNTV2OL2lQTdzilUnstSQf8s7JdmS+zErGyn6kvFhQYpXEHPNq01cfxktKBS6iBTnX50LdoLSLjIBiQUCIjHQeffyL*4GP6kh*3sxXGGTluxyVjBvXWKYFd3b2GvZoVx8NbDsQNbs7bAsQ2M9OllRggoclMVWWnCOGHF2IS8uxG0qqr3ZwHWEIlNRc40M1XdJRd5r7cA*svzLCujWR0AMdxrEQREWVR9LwgnfTygT+Ts6Q+FU+BKizTdwcSdcNM8rK0OvQE5FeRdOYhWHCHtFdEsYoy4hAzfEV8JkhunTx1h0uYRrfTl2gT6mP43W0RyTAlLuujU9*2Rod9ljHSRR+UyOew9yV2*0YpjKGLf3FqLZoDKMx01NR8kYa8b5ALY1+2Y65e6FRNDOZWT6PNvx5+mbr14DncV6JatWsp*RXJkPZG8C8FX+t+2FAI5qFx1kRfBtr*iTW2x3ARWErGPcJqXYcIPhkSdSQUAaZXCgq2XksL+e3dzKeiXKkgWvbXdwb0TmuaJBD6bTIhg2x9LOHXN9ojc+qP4QJ9gwgSMsOgDyFmWHE14cP*YwH+U8T0Gyd2KDmy27oP6wJNr2BFpspCyKK44JOaWx4XXjt6qUMO8jMDHHrxYWJ5LMLxYh19m+m841wpmMofe1p3jJEzkpkwoKae+9FDFOrJEYpYpyOOecB2awQACe82H1evxlFPeTCdjERWA+WVA5IRZAAvygPGDTWEOxkTKGDMFtki9Iqyd4AAdHqBDGUbYkUJWK8taRVboENcW51X1ZObpx0CeIrH70Jq7p05OZKbcWQDTEMZ87jp4Eth8RFITkqODj0ApAtBAG0rKnx1+rfO3LY1VtCFtV7l9DpAcntZVbHDWdt+tAMglsuXdy4UBuMUs5XoxCA*AwM8DB7MMEO8lTEBvQ+VL0glL5IoGNMy0Mb5OMWCHJoEktRALAODXlvD67um4qeH*CmaJVohwu0y5pPOep9X7VdDD5EppWsIGSP4P33jTJ+B2go7FOAWHV7KfRchp*PNNq2qzpdSB7vSaxj3k097FA*zuaFTwjm6a8nOawRNn*MTlKHVqN4Syc0p*M3mw+Z0Q==';
  headers_object = new HttpHeaders().set('Authorization', 'Bearer ' + this.t);
  httpOptions = {
    headers: this.headers_object
  };

  phoneValidatorServiceCall(input): Observable<any> {
    return this.http.post<any>(this.sharedUrlService.getApplicationURL('PhoneValidationApi'),
      { 'Text': input }, this.httpOptions);
  }

  emailValidatorServiceCall(input): Observable<any> {
    return this.http.post<any>(this.sharedUrlService.getApplicationURL('EmailValidationApi'),
      { 'Text': input }, this.httpOptions);
  }

  dunsValidatorServiceCall(input): Observable<any> {

    return this.http.post<any>(this.sharedUrlService.getApplicationURL('DUNSValidationApi'), { 'Text': input }, this.httpOptions);
  }

  einValidatorServiceCall(input): Observable<any> {
    return this.http.post<any>(this.sharedUrlService.getApplicationURL('TaxIdValidationApi'),
      { 'Id_Val': input, 'Id_Type': 'EIN' }, this.httpOptions);
  }

  vatValidatorServiceCall(input): Observable<any> {
    return this.http.post<any>(this.sharedUrlService.getApplicationURL('TaxIdValidationApi'),
      { 'Id_Val': input, 'Id_Type': 'VAT' }, this.httpOptions);
  }
  addressValidatorServiceCall(input): Observable<any> {
    return this.http.post<any>(this.sharedUrlService.getApplicationURL('AddressValidationApi'), { 'Text': input }, this.httpOptions);
  }
  phoneValidator(control: AbstractControl): Observable<ValidationErrors | null> {

    if (control.value == '' || control.value == undefined || control.value == null) {
      return of(null);
    } else {
      return this.phoneValidatorServiceCall(control.value)
        .pipe(map((data: any) => {
          return (data.returnValue === true ? null : { phoneValidator: true });
        }))
    }
  }

  emailValidator(control: AbstractControl): Observable<ValidationErrors | null> {

    if (control.value === '' || control.value === undefined || control.value === null) {
      return of(null);
    } else {
      return this.emailValidatorServiceCall(control.value)
        .pipe(map((data: any) => {
          return (data.returnValue === true ? null : { emailValidator: true });
        }))
    }
  }

  dunsValidator(control: AbstractControl): Observable<ValidationErrors | null> {

    if (control.value === '' || control.value === undefined || control.value === null) {
      return of(null);
    } else {
      return this.dunsValidatorServiceCall(control.value)
        .pipe(map((data: any) => {
          return (data.returnValue === true ? null : { dunsValidator: true });
        }))
    }
  }

  einValidator(control: AbstractControl): Observable<ValidationErrors | null> {

    if (control.value === '' || control.value === undefined || control.value === null) {
      return of(null);
    } else {
      return this.einValidatorServiceCall(control.value)
        .pipe(map((data: any) => {
          return (data.returnValue === true ? null : { einValidator: true });
        }))
    }
  }

  vatValidator(control: AbstractControl): Observable<ValidationErrors | null> {

    if (control.value === '' || control.value === undefined || control.value == null) {
      return of(null);
    } else {
      return this.vatValidatorServiceCall(control.value)
        .pipe(map((data: any) => {
          return (data.returnValue === true ? null : { vatValidator: true });
        }));
    }
  }

  addressValidator(group: FormGroup): Observable<ValidationErrors | null> {
    if (!group || !group.controls['AddressLine1'] || !group.controls['City'] || !group.controls['Country']) {
      return of(null);

    }
    if (!(group.controls['AddressLine1'].dirty && group.controls['City'].dirty && group.controls['Country'].dirty)) {
      console.log('address 1', !(group.controls['AddressLine1'].dirty && group.controls['City'].dirty && group.controls['Country'].dirty))
      return of(null);
    }
    if (!group.controls['AddressLine1'].value || !group.controls['City'].value || !group.controls['Country'].value) {
      return of(null);
    } else {
      const input = {
        'addressLine1': group.controls['AddressLine1'].value,
        'addressLine2': group.controls['AddressLine2'].value,
        'addressLine3': group.controls['AddressLine3'].value,
        'city': group.controls['City'].value,
        'state': group.controls['State'].value,
        'zip': group.controls['Zip'].value,
        'country': group.controls['Country'].value

      };

      return this.addressValidatorServiceCall(input)
        .pipe(map((data: any) => {
          return (data.returnValue === true ? null : { addressValidator: true });
        }));
    }
  }
  optionRequired(control: AbstractControl) {
    if (control.value && (typeof control.value && Object.keys(control.value).length > 0)) {
      return null;
    } else {
      return { optionRequired: true };
    }
  }
}
