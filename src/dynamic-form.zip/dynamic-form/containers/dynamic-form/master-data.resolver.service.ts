import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DynamicFormService } from './dynamic-form.service';
import { SupplierService } from '../../../../../src/modules/supplier/service/supplier.service';
import { map } from 'rxjs/operators/map';

@Injectable({ providedIn: 'root' })
export class MasterDataResolver implements Resolve<any> {
  constructor(private supplierSvr: SupplierService,
    private dynamicFormService: DynamicFormService) { }

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> | Promise<any> | any {
    //return this.dynamicService.getSupplierGraphData(route.paramMap.get('id'));
   return  this.supplierSvr.MasterDataCodeValue().pipe(map(data => {
      this.dynamicFormService.setCodeValues(data['returnValue']);
      return data['returnValue'];
  }));
  }
}
