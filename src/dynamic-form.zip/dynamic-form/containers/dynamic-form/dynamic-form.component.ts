import {
  Component, EventEmitter, Input, OnInit, Output,
  ViewChild, ComponentFactoryResolver, ViewContainerRef, ComponentRef, ElementRef, Renderer2, ViewEncapsulation
} from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { CustomValidation } from '../../validators/custom.validation';
import { Router } from '@angular/router';
import { CrossRefLoaderDirective } from '../supplier-crossref/cross-ref-loader.directive';
import { CrossRefLocationDirective } from '../supplier-crossref/cross-ref-location.directive';
import { CrossRefIdentifictionDirective } from '../supplier-crossref/cross-ref-identification.directive';
import { SupplierCrossrefComponent } from '../supplier-crossref/supplier-crossref.component';
import dataIdentification from '../../../../configs/forms/cross-Identification.json';
import data from '../../../../configs/forms/cross-supplier.json';
import datalocation from '../../../../configs/forms/cross-location.json';
import { Subscription } from 'rxjs';
import { ActionService } from '../../../../modules/supplier/action-buttons/action.service';
import { DynamicFormService } from './dynamic-form.service';
import { FormConfig, CardConfig } from '../../form-config.model';
@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DynamicFormComponent implements OnInit {
  rulesData;
  isShow = false;
  subscription: Subscription;
  @ViewChild(CrossRefLoaderDirective, { static: false }) crossrefLoader: CrossRefLoaderDirective;
  @ViewChild(CrossRefLocationDirective, { static: false }) crossrefLocation: CrossRefLocationDirective;
  @ViewChild(CrossRefIdentifictionDirective, { static: false }) crossrefIdentification: CrossRefIdentifictionDirective;
  @Input()
  Config: FormConfig;

  @Input()
  Service: any;

  @Input()
  FormValues: any = null;
  @Input() formmode: any

  Form: FormGroup;
  Value: any;
  IsSubmitted: boolean = false;
  FormSubmitTracker = new BehaviorSubject<boolean>(this.IsSubmitted);
  FormEnabled: boolean = false;
  SyncFieldValidations;
  AsyncFieldValidations;
  IsDestroy = false;
  ShowCrossRef: boolean = true;
  componentRef: any;
  componentRefLocation: any;
  componentRefBasicDetails: any;
  componentRefIdentification: any;

  @Output()
  submitted: EventEmitter<any> = new EventEmitter();
  // componentFactoryResolver: any;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private cv: CustomValidation,
    private componentFactoryResolver: ComponentFactoryResolver,
    private actionService: ActionService,
    private renderer: Renderer2,
    private dynamicFormService: DynamicFormService) { }

  ngOnInit() {
    this.Config.formCards = this.Config.formCards.map(
      card => {
        card._isEditing = false;
        card._showingCrossRef = false;
        return card;
      }
    )

    this.Form = this.dynamicFormService.createFormGroup(this.Config, this.FormValues);
    this.submitted.emit(this.Form);
    this.Form.valueChanges.subscribe((data: any) => {
      console.log('Value Changed ', this.Form.getRawValue());
      this.submitted.emit(this.Form);
     // if(!this.Form.pristine && this.Form.dirty){
       if(this.dynamicFormService.getIsAddCancel()){
        this.Config.formCards.map((formCard) =>{
          if(formCard.cardFormType.toLowerCase() === 'multi'){

            (this.Form.controls[formCard.cardName] as FormArray).clear();
            if(this.formmode === 'view' && this.FormValues[formCard.cardName].length > 0){
              this.dynamicFormService.setIsAddCancel(false);
              this.Form.controls[formCard.cardName] =  this.dynamicFormService.createFormElement(formCard, this.FormValues) as FormArray;
            }
            else{
              this.dynamicFormService.setIsAddCancel(false);
              this.Form.controls[formCard.cardName] =  this.dynamicFormService.createFormElement(formCard, undefined) as FormArray;
              //this.createNewForm(this.formConfig);
            }
          }
      })
       }


     // }

    })
    //Set Form Data dynamically
    this.dynamicFormService.setFormData(this.Form);
    console.log('this', this.Form);
    this.subscription = this.actionService.getSupplierCrossrefData().subscribe(data => {
      this.crossrefAll('basicdetails');
      this.crossrefAll('location');
      this.crossrefAll('identification');
    });
    this.dynamicFormService.setFormMode(this.formmode);
  }

  CreateGroup() {
    const group = this.fb.group({}, { updateOn: 'blur' });
    this.Config.formCards.forEach(card => {
      const subGroup = this.fb.group({});
      const CardSyncFieldValidations = [];
      const CardAsyncFieldValidations = [];

      if (card.validators) {
        card.validators.forEach(v => {

          if (v.parameters != null) {
            //With Parameters

            if (v.isAsync) {
              //Async validation with parameter
              CardAsyncFieldValidations.push(this.cv.ValidatorList[v.validator](v.parameters));
            }
            else {
              //Sync validation with parameter
              CardSyncFieldValidations.push(this.cv.ValidatorList[v.validator](v.parameters));
            }
          }
          else {
            //Without Parameters

            if (v.isAsync) {
              //Async validation without parameter
              CardAsyncFieldValidations.push(this.cv.ValidatorList[v.validator]);
            }
            else {
              //Sync validation without parameter
              CardSyncFieldValidations.push(this.cv.ValidatorList[v.validator]);
            }
          }
        });
      }
      if (CardSyncFieldValidations.length) { subGroup.setValidators(CardSyncFieldValidations); }
      if (CardAsyncFieldValidations.length) { subGroup.setAsyncValidators(CardAsyncFieldValidations); }
      //subGroup.updateValueAndValidity();
      card.cardContent.forEach(control => {

        //Fetching validations from config(Start)
        this.SyncFieldValidations = [];
        this.AsyncFieldValidations = [];

        if (control.validators != null) {

          control.validators.forEach(v => {

            if (v.parameters != null) {
              //With Parameters

              if (v.isAsync) {
                //Async validation with parameter
                this.AsyncFieldValidations.push(this.cv.ValidatorList[v.validator](v.parameters));
              }
              else {
                //Sync validation with parameter
                this.SyncFieldValidations.push(this.cv.ValidatorList[v.validator](v.parameters));
              }
            }
            else {
              //Without Parameters

              if (v.isAsync) {
                //Async validation without parameter
                this.AsyncFieldValidations.push(this.cv.ValidatorList[v.validator]);
              }
              else {
                //Sync validation without parameter
                this.SyncFieldValidations.push(this.cv.ValidatorList[v.validator]);
              }
            }
          });
        }
        //Fetching validations from config(End)

        if (this.FormValues && this.FormValues[card.cardName][control.name]) { //Edit Mode

          this.Value = this.FormValues[card.cardName][control.name] ? this.FormValues[card.cardName][control.name] : '';

          if (this.AsyncFieldValidations.length > 0 || this.SyncFieldValidations.length > 0) {
            //Applying Validation

            if (this.AsyncFieldValidations.length > 0 && this.SyncFieldValidations.length > 0) {
              subGroup.addControl(control.name, this.fb.control({ value: this.Value }, this.SyncFieldValidations, this.AsyncFieldValidations));
            }
            else if (this.AsyncFieldValidations.length > 0 && this.SyncFieldValidations.length == 0) {
              subGroup.addControl(control.name, this.fb.control({ value: this.Value, disabled: 'true' }, null, this.AsyncFieldValidations));
            }
            else {
              subGroup.addControl(control.name, this.fb.control({ value: this.Value, disabled: 'true' }, this.SyncFieldValidations));
            }
          }
          else {
            //No Validation
            subGroup.addControl(control.name, this.fb.control({ value: this.Value, disabled: 'true' }));
          }
        }
        else { //Add Mode

          if (this.AsyncFieldValidations.length > 0 || this.SyncFieldValidations.length > 0) {
            //Applying Validation

            if (this.AsyncFieldValidations.length > 0 && this.SyncFieldValidations.length > 0) {
              subGroup.addControl(control.name, this.fb.control('', this.SyncFieldValidations, this.AsyncFieldValidations));
            }
            else if (this.AsyncFieldValidations.length > 0 && this.SyncFieldValidations.length == 0) {
              subGroup.addControl(control.name, this.fb.control('', null, this.AsyncFieldValidations));
            }
            else {
              subGroup.addControl(control.name, this.fb.control('', this.SyncFieldValidations));
            }
          }
          else {
            //No Validation
            subGroup.addControl(control.name, this.fb.control(''));
          }
        }
        subGroup.addControl('selected', this.fb.control(true));
      })

      if (card.cardFormType.toLowerCase() === 'multi') {
        const formArray = this.fb.array([]);
        formArray.push(subGroup);
        group.addControl(card.cardName, formArray);
      } else {
        group.addControl(card.cardName, subGroup);
      }


    }
    );
    if (this.FormValues != null) { //Edit Mode
      this.FormValues = group.value;
    }
    return group;

  }

  DeleteSelected(card, button) {
    var formData = this.dynamicFormService.getFormData();
    formData.controls[card.cardName].controls = this.getFormArrayControls(card.cardName).controls;
    var notDeletedFormGroupArr = [];
    var notDeletedFormValArr = [];
    var formValue = [];
    var sampleData = formData.controls[card.cardName].controls;

    sampleData.map((form: any) => {
      console.log(form);
      if (!form.isChecked) {
        notDeletedFormGroupArr.push(form);
        notDeletedFormValArr.push(form.value);
      }
    });

    formData.controls[card.cardName].controls = notDeletedFormGroupArr;
    formData.value[card.cardName] = notDeletedFormValArr;

    this.dynamicFormService.setFormData(formData);
    this.getFormArrayControls(card.cardName).controls = formData.controls[card.cardName].controls;
    if (this.getFormArrayControls(card.cardName).controls.length > 0) {
      this.getFormArrayControls(card.cardName).controls.map((form: any) => {
        form.selected = false;
      });

      //this.getFormArrayControls(card.cardName).controls[0].selected = true;



    }

    // var arrayList = this.getFormArrayControls(card.cardName);
    // arrayList.controls.map((form: any) => {
    //   console.log(form);
    // });
  }

  EnableFormFields(card, button) {
    this.toggleCrossRefInfo();
    if (this.FormValues != null) {
      Object.keys(this.Form.controls).forEach(key => {
        if (card.cardName === key) {
          this.setCardEditMode(card);
          this.Form.controls[key].markAsDirty();
          this.Form.controls[key].enable();
          const formSubgroupControls = (this.Form.controls[key] as FormGroup).controls;
          Object.keys(formSubgroupControls).map(control => {
            formSubgroupControls[control].enable();
            formSubgroupControls[control].markAsDirty();
          })
        }
      }
      );
      // this.Config.FormButtons.forEach(button => {
      //   if (button.Display == true) {
      //     button.Display = false;
      //   }
      //   else {
      //     button.Display = true;
      //   }
      // });
    }
  }

  ResetForm(card, form) {
    this.toggleCrossRefInfo();

    if (this.FormValues != null) {
      this.Form.reset(this.FormValues);
      Object.keys(this.Form.controls).forEach(key => {
        if (card.cardName === key) {
          this.setCardEditCancelMode(card);
          (this.Form.controls[key] as FormControl).disable();
          this.Config.formButtons.forEach(button => {
            if (button.display == true) {
              button.display = false;
            } else {
              button.display = true;
            }
          });
        }
      });
    } else {
      //For add form
      this.Form.reset();
    }
  }

  OnSubmit(Form) {
    this.submitted.emit(this.Form);
    this.IsSubmitted = true;
    this.FormSubmitTracker.next(this.IsSubmitted);
    this.Config.formCards = this.Config.formCards.map(card => {
      this.setCardEditCancelMode(card);
      return card;
    });
  }

  NavigateToPath(path) {
    this.router.navigate([path]);
  }

  crossrefAll(crossrefProperty) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(SupplierCrossrefComponent);
    let viewContainerRef;
    if (crossrefProperty.toLowerCase() === 'basicdetails') {
      viewContainerRef = this.crossrefLoader.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefBasicDetails) {
        this.componentRefBasicDetails = !this.componentRefBasicDetails;
      } else {
        this.componentRefBasicDetails = viewContainerRef.createComponent(componentFactory);
        this.componentRefBasicDetails.instance.crossrefProperty = crossrefProperty;
        this.componentRefBasicDetails.instance.inputColumns = ['Source Information', 'Source System ID', 'Supplier Legal Name', 'Year of Corporation', 'Ownership Type', 'Business Type', 'Business Criticality'];
        this.componentRefBasicDetails.instance.inputData = data;
      }

    } else if (crossrefProperty.toLowerCase() === 'location') {
      //alert(crossrefProperty.toLowerCase());
      viewContainerRef = this.crossrefLocation.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefLocation) {
        this.componentRefLocation = !this.componentRefLocation;
      } else {
        this.componentRefLocation = viewContainerRef.createComponent(componentFactory);
        this.componentRefLocation.instance.crossrefProperty = crossrefProperty;
        this.componentRefLocation.instance.inputColumns = ['Source Information', 'Source System ID', 'Address line 1', 'Address line 2', 'Address line 3', 'City', 'State', 'Zip', 'Country'];
        this.componentRefLocation.instance.inputData = datalocation;
        //alert(viewContainerRef);
      }

    }
    else if (crossrefProperty.toLowerCase() === 'identification') {
      //alert(crossrefProperty.toLowerCase());
      viewContainerRef = this.crossrefIdentification.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefIdentification) {
        this.componentRefIdentification = !this.componentRefIdentification;
      } else {
        this.componentRefIdentification = viewContainerRef.createComponent(componentFactory);
        this.componentRefIdentification.instance.crossrefProperty = crossrefProperty;
        this.componentRefIdentification.instance.inputColumns = ['Source Information', 'Source System ID', 'DUNS', 'EIN', 'VAT'];
        this.componentRefIdentification.instance.inputData = dataIdentification;
      }

      //alert(viewContainerRef);
    }
  }
  crssrefbasic(crossrefProperty) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(SupplierCrossrefComponent);
    let viewContainerRef;
    this.Config.formCards = this.Config.formCards.map(card => {
      if (card.cardName.toLowerCase() === crossrefProperty.toLowerCase()) {
        card._showingCrossRef = false;
      }
      return card;
    })
    if (crossrefProperty.toLowerCase() === 'basicdetails') {
      this.Config.formCards = this.Config.formCards.map(card => {
        if (card.cardName.toLowerCase() === 'basicdetails') {
          card._showingCrossRef = true;
        }
        return card;
      }
      );


      viewContainerRef = this.crossrefLoader.viewContainerRef;
    } else if (crossrefProperty.toLowerCase() === 'location') {
      this.Config.formCards = this.Config.formCards.map(card => {
        if (card.cardName.toLowerCase() === 'location') {
          card._showingCrossRef = true;
        }
        return card;
      })
      viewContainerRef = this.crossrefLocation.viewContainerRef;
    } else if (crossrefProperty.toLowerCase() === 'identification') {
      this.Config.formCards = this.Config.formCards.map(card => {
        if (card.cardName.toLowerCase() === 'identification') {
          card._showingCrossRef = true;
        }
        return card;
      })
      viewContainerRef = this.crossrefIdentification.viewContainerRef;
    }
    viewContainerRef.clear();


    if (crossrefProperty.toLowerCase() === 'basicdetails') {
      if (this.componentRefLocation) {
        this.componentRefLocation.destroy();
      }
      if (this.componentRefIdentification) {
        this.componentRefIdentification.destroy();
      }
      if (this.componentRefBasicDetails) {
        this.componentRefBasicDetails = !this.componentRefBasicDetails;
      } else {
        this.componentRefBasicDetails = viewContainerRef.createComponent(componentFactory);
        this.componentRefBasicDetails.instance.crossrefProperty = crossrefProperty;
        this.componentRefBasicDetails.instance.inputColumns = ['Source Information', 'Source System ID', 'Supplier Legal Name', 'Year of Corporation', 'Ownership Type', 'Business Type', 'Business Criticality'];
        this.componentRefBasicDetails.instance.inputData = data;
      }
    } else if (crossrefProperty.toLowerCase() === 'location') {
      if (this.componentRefBasicDetails) {
        this.componentRefBasicDetails.destroy();
      }
      if (this.componentRefIdentification) {
        this.componentRefIdentification.destroy();
      }
      if (this.componentRefLocation) {
        this.componentRefLocation = !this.componentRefLocation;
      } else {
        this.componentRefLocation = viewContainerRef.createComponent(componentFactory);
        this.componentRefLocation.instance.crossrefProperty = crossrefProperty;
        this.componentRefLocation.instance.inputColumns = ['Source Information', 'Source System ID', 'Address line 1', 'Address line 2', 'Address line 3', 'City', 'State', 'Zip', 'Country'];
        this.componentRefLocation.instance.inputData = datalocation;
      }
    } else if (crossrefProperty.toLowerCase() === 'identification') {

      if (this.componentRefBasicDetails) {
        this.componentRefBasicDetails.destroy();
      }
      if (this.componentRefLocation) {
        this.componentRefLocation.destroy();
      }
      if (this.componentRefIdentification) {
        this.componentRefIdentification = !this.componentRefIdentification;
      } else {
        this.componentRefIdentification = viewContainerRef.createComponent(componentFactory);
        this.componentRefIdentification.instance.crossrefProperty = crossrefProperty;
        this.componentRefIdentification.instance.inputColumns = ['Source Information', 'Source System ID', 'DUNS', 'EIN', 'VAT'];
        this.componentRefIdentification.instance.inputData = dataIdentification;
      }
    }

  }
  toggleCrossRefInfo() {
    this.ShowCrossRef = !this.ShowCrossRef;
    if (this.componentRefBasicDetails) {
      this.componentRefBasicDetails.destroy();
    }
    if (this.componentRefLocation) {
      this.componentRefLocation.destroy();
    }
    if (this.componentRefIdentification) {
      this.componentRefIdentification.destroy();
    }
    //this.ShowCrossRef = !this.ShowCrossRef;
  }

  shouldDisplayDeleteButton(card, button) {

  }

  shouldDisplayButtons(card, button) {
    if (card._isEditing === true && (button.name === 'Save' || button.name === 'Cancel')) {
      return false;
    } else if (card._isEditing !== true && button.name === 'Delete' && card.cardFormType.toLowerCase() == 'multi') {
      return true;
    } else if (card._isEditing !== true && button.name === 'Edit' && card.cardFormType.toLowerCase() == 'basic') {
      return false;
    } else {
      return false;
    }
    return false;
  }
  setCardEditMode(card) {
    this.Config.formCards = this.Config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isEditing = true;
      }
      return c;
    })
  }
  setCardEditCancelMode(card) {
    this.Config.formCards = this.Config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isEditing = false;
      }
      return c;
    });
  }
  getFormGroup(groupName) {
    return this.Form.controls[groupName];
  }
  getFormArrayControls(groupName) {
    return (this.Form.controls[groupName] as FormArray);
  }
  getSelectedFormInArr(groupName: string) {
    const formArray = this.getFormGroup(groupName) as FormArray;
    return formArray.controls.find((form: FormGroup) => form.controls.selected.value);
  }

}
