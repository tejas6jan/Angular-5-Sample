import { Supplier, identifications, CodeValue } from './../../../../modules/supplier/model/supplier.model';

import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import FormConfig from '../../../../configs/forms/view-supplier.json';
import { CardConfig, FormButton, CardContent } from '../../form-config.model';
import { FormControlsService } from '../../form-controls.service';
import { CustomValidation } from '../../validators/custom.validation';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

@Injectable()
export class DynamicFormService {
  public supModel: Supplier = new Supplier();
  private formData: any;
  private formMode: any;
  private codeValue: any;
  private isAddCancel: any;
  private resetData: any;
  private renderer: Renderer2;
  constructor(private formControl: FormControlsService,
    private cv: CustomValidation,
    rendererFactory: RendererFactory2,
    private fb: FormBuilder) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }
  getSupplierViewConfig(): Observable<any> {
    const viewConfig = Object.assign({}, FormConfig);
    return of(viewConfig);
  }
  createFormCard(cardConfig: CardConfig): any {
    const matCard = this.renderer.createElement('mat-card');

    /** Add classes to card */
    this.renderer.addClass(matCard, 'mat-card');
    /** Create Card Title */
    matCard.appendChild(this.createMatCardTitle(cardConfig));
    /** Create Card Content */
    matCard.appendChild(this.createMatCardContent(cardConfig));

    return matCard;
  }
  createMatCardTitle(cardConfig) {
    const matCardTitle = this.renderer.createElement('mat-card-title');
    this.renderer.addClass(matCardTitle, 'mat-card-title');
    const title = this.renderer.createText(cardConfig.cardLabel);
    matCardTitle.appendChild(title);
    if (cardConfig.cardButtons && cardConfig.cardButtons.length) {
      const titleButtons = this.createTitleButtons(cardConfig.cardButtons);
      matCardTitle.appendChild(titleButtons);
    }
    return matCardTitle;
  }
  /**
   * createTitleButtons()
   *  @param
   * cardButtons: array of buttons with the scope of current card.
   *  @summary
   * Function returns a div block that holds button in mat-title bar
   * ============Sample block=================
   * <div class="button-container">
  *     <ng-container *ngFor="let fb of Config.FormButtons">
  *       <button mat-button color="primary" *ngIf="shouldDisplayButtons(card,fb)"
  *  (click)="this[fb.Onclick](card,fb)"
  *         [type]="fb.Type?fb.Type:''">
  *         <i *ngIf="fb.icon" class="icon small opener">
  *           <svg focusable="false">
  *             <use xmlns:xlink="http://www.w3.org/1999/xlink" attr.xlink:href="#{{fb.icon}}"></use>
  *           </svg>
  *         </i>
  *         {{ fb.Label }}</button>
  *     </ng-container>
  *   </div>
  * =============================================
   */
  createTitleButtons(cardButtonsConfig) {
    const titleButtonContainer = this.renderer.createElement('div');
    this.renderer.addClass(titleButtonContainer, 'button-container');
    cardButtonsConfig.map(buttonConfig => {
      const button = this.formControl.createButton(buttonConfig);
      titleButtonContainer.appendChild(button);
    });
    return titleButtonContainer;

  }

  createMatCardContent(cardConfig: CardConfig) {
    const matCardContent = this.renderer.createElement('mat-card-content');
    this.renderer.addClass(matCardContent, 'mat-card-content');
    cardConfig.cardContent.map(cardElement => {
      let control;
      switch (cardElement.type) {
        case 'input':
          control = this.formControl.createInput(cardElement);
          break;
        default:
          control = this.formControl.createInput(cardElement);
          break;
      }
      this.renderer.appendChild(matCardContent, control);
    });
    return matCardContent;
  }
  createFormGroup(formConfig, formValue) {
    const group = this.fb.group({}, { updateOn: 'blur' });
    formConfig.formCards.forEach((card: CardConfig) => {
      group.addControl(card.cardName, this.createFormElement(card, formValue));
    });
    return group;
  }
  createFormElement(card, formValue): FormGroup | FormArray {
    let formElement;
    if (card.cardFormType.toLowerCase() === 'multi') {
      formElement = this.fb.array([]);
      if (formValue && formValue[card.cardName] && formValue[card.cardName].length) {
        for (let index = 0; index < formValue[card.cardName].length; index++) {
          formElement.push(this.createSubGroup(card, formValue[card.cardName][index]));
        }
        formElement.controls[0].selected = true;
      }
    } else {
      if (formValue) {
          formElement = this.createSubGroup(card, formValue[card.cardName]);
      }else{
        formElement = this.createSubGroup(card, formValue);
      }
    }
    return formElement;
  }
  createSubGroup(card: CardConfig, formValue) {
    const formSubGroup = this.fb.group({});
    /** Set FormGroup Validtions  */
    this.setCardValidations(card, formSubGroup, formValue);
    /**  Set FormGroup Controls   */
    this.setCardFormControls(card, formSubGroup, formValue);
    (formSubGroup as any).selected = false;
    (formSubGroup as any).isChecked = false;
    return formSubGroup;
  }
  setCardValidations(card, formSubGroup, formValue) {
    if (card.validators && card.validators.length) {
      const CardSyncFieldValidations = [];
      const CardAsyncFieldValidations = [];
      card.validators.map(v => {
        if (v.isAsync) {
          CardAsyncFieldValidations.push(v.parameters ?
            this.cv.ValidatorList[v.validator](v.parameters) : this.cv.ValidatorList[v.validator]);
        } else {
          CardSyncFieldValidations.push(v.parameters ?
            this.cv.ValidatorList[v.validator](v.parameters) : this.cv.ValidatorList[v.validator]);
        }
      });

      formSubGroup.setValidators(CardSyncFieldValidations);
      formSubGroup.setAsyncValidators(CardAsyncFieldValidations);
    }
  }
  setCardFormControls(card, formSubGroup, formValue) {
    card.cardContent.map(control => {
      const SyncFieldValidations = [];
      const AsyncFieldValidations = [];

      if (control.validators) {
        control.validators.forEach(v => {
          if (v.isAsync) {
            AsyncFieldValidations.push(v.parameters ?
              this.cv.ValidatorList[v.validator](v.parameters) : this.cv.ValidatorList[v.validator]);
          } else {
            SyncFieldValidations.push(v.parameters ?
              this.cv.ValidatorList[v.validator](v.parameters) : this.cv.ValidatorList[v.validator]);
          }
        });
      }
      let formControl = null;
      if (control.type === 'multiselect') {
        formControl = this.fb.control({value:[]});
      }
      if (control.type === 'select') {
        formControl = this.fb.control({});
      }
      else {
        formControl = this.fb.control('');
      }

      formControl.setAsyncValidators(AsyncFieldValidations);
      formControl.setValidators(SyncFieldValidations);

      if (formValue) {

        if (card.cardFormValue.toLowerCase() === "array") {
          console.log('Card....', card);
          if (formValue.find(item => { return item.name.toLowerCase() === control.name.toLowerCase() })) {
            formControl.setValue(formValue.find(item => { return item.name.toLowerCase() === control.name.toLowerCase() }).value);
          }

        }
        else {
          formControl.setValue(formValue[control.name]);
        }
        formControl.disable();
      }
      else {
        formControl.enable();
      }
      //formControl.disable();
      formSubGroup.addControl(control.name, formControl);
    });
  }

  getFormData() {
    return this.formData;
  }

  setFormData(value) {
    this.formData = value;
  }

  getResetData(){
    return this.resetData;
  }

  setResetData(value){
    this.resetData = value;
  }

  getFormMode(){
    return this.formMode;
  }

  setFormMode(value){
    this.formMode = value;
  }

  getCodeValues(name){
    if(this.codeValue){
      return this.codeValue[name];
    }
  }

  setCodeValues(value){
      this.codeValue = value;
  }

  getIsAddCancel(){
       return this.isAddCancel;
  }

  setIsAddCancel(value){
      this.isAddCancel = value;
  }

  generatePostSupplierData(supControl: FormGroup, identification: any, socialMedia: any) {

    this.supModel.basicDetails = supControl.getRawValue().basicDetails;
    this.supModel.contacts = supControl.getRawValue().contacts;
    this.supModel.identifications = identification;
    this.supModel.locations = supControl.getRawValue().locations;
    this.supModel.socialMedia = socialMedia;

    return this.supModel;
  }

}
