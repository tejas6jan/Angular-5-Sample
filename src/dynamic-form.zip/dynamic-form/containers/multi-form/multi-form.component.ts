import { Component, OnInit, Input, ViewChild, ComponentFactoryResolver } from '@angular/core';
import { FormArray, FormGroup, FormControl } from '@angular/forms';
import { CardContent, CardConfig, FormButton, FormConfig } from '../../form-config.model';
import { DynamicFormService } from '../dynamic-form/dynamic-form.service';
import { ActionService } from '../../../../modules/supplier/action-buttons/action.service';
import { Subscription } from 'rxjs';
import { CrossRefLoaderDirective } from '../supplier-crossref/cross-ref-loader.directive';
import { CrossRefLocationDirective } from '../supplier-crossref/cross-ref-location.directive';
import { CrossRefIdentifictionDirective } from '../supplier-crossref/cross-ref-identification.directive';
import { CustomValidation } from '../../validators/custom.validation';
import { SupplierCrossrefComponent } from '../supplier-crossref/supplier-crossref.component';
import data from '../../../../configs/forms/cross-supplier.json';
import datalocation from '../../../../configs/forms/cross-location.json';
import dataIdentification from '../../../../configs/forms/cross-Identification.json';

@Component({
  selector: 'app-multi-form',
  templateUrl: './multi-form.component.html',
  styleUrls: ['./multi-form.component.scss']
})
export class MultiFormComponent implements OnInit {
  selectAllChecked: boolean = false;
  formmode : string;
  selectPrimaryChecked: boolean = false;
  isAlreadyPrimary: boolean = false;
  selectedGroup: any;
  textVal: string;
  subscription: Subscription;
  ShowCrossRef: boolean = true;
  componentRef: any;
  componentRefLocation: any;
  componentRefBasicDetails: any;
  componentRefIdentification: any;
  addressText: string = "";
  isAddnewSelected = false;
  _multiFormArray: FormArray;
  @ViewChild(CrossRefLoaderDirective, { static: false }) crossrefLoader: CrossRefLoaderDirective;
  @ViewChild(CrossRefLocationDirective, { static: false }) crossrefLocation: CrossRefLocationDirective;
  @ViewChild(CrossRefIdentifictionDirective, { static: false }) crossrefIdentification: CrossRefIdentifictionDirective;
  constructor(private dynamicFormService: DynamicFormService,
    private actionService: ActionService,
    private cv: CustomValidation,
    private componentFactoryResolver: ComponentFactoryResolver, ) { }
  //@Input() multiFormArray: FormArray;
  @Input() set multiFormArray(cval: FormArray) {
    this._multiFormArray = cval;
    if (this.config) { this.initializeForm() }
  };
  @Input() formConfig: CardConfig;
  @Input() formButton: FormButton;
  @Input()
  formValues: any = null;
  @Input()
  config: FormConfig;
  @Input() formMode: any;

  Form: FormGroup;
  ngOnInit() {
    this.textVal = 'samiksha';
    console.log('Multi Form Component Initialize.........');
    console.log('_multiFormArray', this._multiFormArray);
    console.log(this.formMode);
    // if(this.formMode === 'add' || (this.formMode ==='view' && ! this.formValues[this.formConfig.cardName].length)){

      this._multiFormArray.valueChanges.subscribe((data: any) => {
        //  if(this._multiFormArray.dirty == false && this._multiFormArray.pristine == true){
        //    this._multiFormArray.clear();
        //    this.createNewForm(this.formConfig);
        //  }
        // this._multiFormArray.clear();
        // if(this.formMode === 'view' && this.formValues[this.formConfig.cardName].length > 0){
        //   this._multiFormArray =  this.dynamicFormService.createFormElement(this.formConfig, this.formValues) as FormArray;
        // }
        // else{
        //   this.createNewForm(this.formConfig);
        // }
   })
    //}


    if (this.config) { this.initializeForm() }

  }
  initializeForm() {
    this.config.formCards = this.config.formCards.map(
      card => {
        if(card.cardName === this.formConfig.cardName && card.cardFormType.toLowerCase() === "multi"){
          card._isEditing = false;
          card._isAddNew = false;
          card._showingCrossRef = false;

        }
        return card;
      }
    );
    if (!this._multiFormArray.controls.length) {
      this.createNewForm(this.formConfig);
    } else {
      // this.Form = this.dynamicFormService.createFormGroup(this.config, this.formValues);
      //Set Form Data dynamically
      // this.dynamicFormService.setFormData(this.Form);
      console.log('this', this.Form);
      this.subscription = this.actionService.getSupplierCrossrefData().subscribe(data => {
        this.crossrefAll('basicdetails');
        this.crossrefAll('location');
        this.crossrefAll('identification');
      });
      this.selectedGroup = this._multiFormArray.controls.find((form: any) => form.selected);
      this.addressText = this.getAddress(this.formConfig, this.selectedGroup);
      if (this.selectedGroup && this.selectedGroup.controls.isPrimary.value == true) {
        this.selectPrimaryChecked = true;
      }
      else {
        this.selectPrimaryChecked = false;
      }
    }
  }

  shouldDisableButton(card, button) {
    if (button.name === 'Save' && !this.selectedGroup.valid) {
      return true;
    } else {
      return false;
    }
  }

  getAddress(config, group) {
    if (!group || !config) { return ''; }
    this.addressText = "";
    if (config.cardName === "locations") {
      if (group.value.addressLine1 && group.value.addressLine1 != "") {
        this.addressText = group.value.addressLine1;
      }
      if (group.value.addressLine2 && group.value.addressLine2 != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.addressLine2;
        }
        else {
          this.addressText = group.value.addressLine2;
        }
      }
      if (group.value.country.name && group.value.country.name != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.country.name;
        }
        else {
          this.addressText = group.value.country.name;
        }
      }
    }
    if (config.cardName === "contacts") {
      if (group.value.firstName && group.value.firstName != "") {
        this.addressText = group.value.firstName;
      }
      if (group.value.middleName && group.value.middleName != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.middleName;
        }
        else {
          this.addressText = group.value.middleName;
        }
      }
      if (group.value.lastName && group.value.lastName != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.lastName;
        }
        else {
          this.addressText = group.value.lastName;
        }
      }
    }

    return this.addressText;
  }

  saveForm(card, button) {
    card._isEditing = false;
    this._multiFormArray.controls.map((fGroup: FormGroup) => {
      fGroup.disable();

    });
    var formData = this.dynamicFormService.getFormData();
    formData.controls[this.formConfig["cardName"]].value = this._multiFormArray.value;
    formData.value[this.formConfig["cardName"]] = this._multiFormArray.value;
    this.dynamicFormService.setFormData(formData);
    //console.log('Updated Form Values : ',this.dynamicFormService.getFormData());
  }

  crossrefAll(crossrefProperty) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(SupplierCrossrefComponent);
    let viewContainerRef;
    if (crossrefProperty.toLowerCase() === 'basicdetails') {
      viewContainerRef = this.crossrefLoader.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefBasicDetails) {
        this.componentRefBasicDetails = !this.componentRefBasicDetails;
      } else {
        this.componentRefBasicDetails = viewContainerRef.createComponent(componentFactory);
        this.componentRefBasicDetails.instance.crossrefProperty = crossrefProperty;
        this.componentRefBasicDetails.instance.inputColumns = ['Source Information', 'Source System ID', 'Supplier Legal Name', 'Year of Corporation', 'Ownership Type', 'Business Type', 'Business Criticality'];
        this.componentRefBasicDetails.instance.inputData = data;
      }

    } else if (crossrefProperty.toLowerCase() === 'location') {
      //alert(crossrefProperty.toLowerCase());
      viewContainerRef = this.crossrefLocation.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefLocation) {
        this.componentRefLocation = !this.componentRefLocation;
      } else {
        this.componentRefLocation = viewContainerRef.createComponent(componentFactory);
        this.componentRefLocation.instance.crossrefProperty = crossrefProperty;
        this.componentRefLocation.instance.inputColumns = ['Source Information', 'Source System ID', 'Address line 1', 'Address line 2', 'Address line 3', 'City', 'State', 'Zip', 'Country'];
        this.componentRefLocation.instance.inputData = datalocation;
        //alert(viewContainerRef);
      }

    }
    else if (crossrefProperty.toLowerCase() === 'identification') {
      //alert(crossrefProperty.toLowerCase());
      viewContainerRef = this.crossrefIdentification.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefIdentification) {
        this.componentRefIdentification = !this.componentRefIdentification;
      } else {
        this.componentRefIdentification = viewContainerRef.createComponent(componentFactory);
        this.componentRefIdentification.instance.crossrefProperty = crossrefProperty;
        this.componentRefIdentification.instance.inputColumns = ['Source Information', 'Source System ID', 'DUNS', 'EIN', 'VAT'];
        this.componentRefIdentification.instance.inputData = dataIdentification;
      }

      //alert(viewContainerRef);
    }
  }

  //this.selectedGroup = this._multiFormArray.controls.find((form :any) => form.selected);
  getSelectedGroup() {

    return this._multiFormArray.controls.find((form: any) => form.selected);

  }
  getTabName(locFormgroup: FormGroup) {
    return Object.values(locFormgroup.controls)[2].value;
  }

  basicFormData($event){
    this._multiFormArray.controls.push($event.data);
    this.openForm($event.card, $event.data);
  }

  createNewForm(card) {
    card._isEditing = false;
    card._isAddNew = true;
    const newFormGroup = this.dynamicFormService.createSubGroup(this.formConfig, undefined);
    this.isAddnewSelected = true;
    this.addressText = "";
    this.selectedGroup = newFormGroup;
    this.selectedGroup.controls.isPrimary.setValue(false);
    if (this._multiFormArray && this._multiFormArray.length) {
      this._multiFormArray.controls.map((form: any) => {
        form.selected = false;
      });
    }
    this.selectPrimaryChecked = false;
    //this.selectedGroup.controls.map((control)=>{control.enable();}).enable();
    Object.keys(this.selectedGroup.controls).forEach(key => {
      this.selectedGroup.controls[key].enable();
    });
    // this.selectedGroup.markAsDirty();
    // this._multiFormArray.push(newFormGroup);
    // this.openForm(newFormGroup);
    //this.EnableFormFields(this.formConfig, this.formButton);



  }

  submitForm() { }

  shouldDisplayDeleteButtons(card, button) {
    if (button.name === 'Delete' && card.cardFormType.toLowerCase() == 'multi') {
      return true;
    }
    else {
      return false;
    }
    return false;
  }

  DeleteSelected(card, button) {
    var formData = this.dynamicFormService.getFormData();
    formData.controls[card.cardName].controls = this._multiFormArray.controls;
    var notDeletedFormGroupArr = [];
    var notDeletedFormValArr = [];
    var formValue = [];
    var sampleData = formData.controls[card.cardName].controls;

    sampleData.map((form: any) => {
      console.log(form);
      if (!form.isChecked) {
        notDeletedFormGroupArr.push(form);
        notDeletedFormValArr.push(form.value);
      }
    });

    formData.controls[card.cardName].controls = notDeletedFormGroupArr;
    formData.value[card.cardName] = notDeletedFormValArr;
    formData.controls[card.cardName].value = notDeletedFormValArr;

    this.dynamicFormService.setFormData(formData);
    var formData = this.dynamicFormService.getFormData();

    this._multiFormArray.controls = formData.controls[card.cardName].controls;
    //this._multiFormArray.value = formData.controls[card.cardName].value;

    if (this._multiFormArray.controls.length > 0) {
      this._multiFormArray.controls.map((form: any, index) => {
        if (index === 0) {
          this.selectedGroup = form;
          form.selected = true;
          //Test Test
          if (form.value.isPrimary == false || form.value.isPrimary == "") {
            this.selectPrimaryChecked = false;
          }
          else {
            this.selectPrimaryChecked = true;
          }
        } else {
          form.selected = false;
        }

      });
    }
    else {
      this.createNewForm(this.formConfig);
    }

  }
  shouldDisplayButtons(card, button) {
    if (card._isEditing === true && (button.name === 'Save' || button.name === 'Cancel')) {
      return true;
    } if ((card._isEditing === false && card._isAddNew === true) && (button.name === 'ADD')) {
      return true;
    } else if ((card._isEditing !== true && card._isAddNew === false) && button.name === 'Edit') {
      return true;
    }
    else {
      return false;
    }
    return false;
  }

  toggleCrossRefInfo() {
    this.ShowCrossRef = !this.ShowCrossRef;
    if (this.componentRefBasicDetails) {
      this.componentRefBasicDetails.destroy();
    }
    if (this.componentRefLocation) {
      this.componentRefLocation.destroy();
    }
    if (this.componentRefIdentification) {
      this.componentRefIdentification.destroy();
    }
    //this.ShowCrossRef = !this.ShowCrossRef;
  }
  setCardEditCancelMode(card) {
    this.config.formCards = this.config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isEditing = false;
      }
      return c;
    });
  }

  ResetForm(card, form) {
    this.toggleCrossRefInfo();
    this.setCardEditCancelMode(card);
    if (this.formValues != null) {
      this._multiFormArray.controls.map((fGroup: FormGroup) => {

        fGroup.disable();
        //fGroup.markAsDirty();
      });
      this.config.formButtons.forEach(button => {
        if (button.display == true) {
          button.display = false;
        } else {
          button.display = true;
        }
      });
      // this.Form.reset(this.formValues);
      // Object.keys(this.Form.controls).forEach(key => {
      //   if (card.cardName === key) {
      //     this.setCardEditCancelMode(card);
      //     (this.Form.controls[key] as FormControl).disable();
      //     this.config.formButtons.forEach(button => {
      //       if (button.display == true) {
      //         button.display = false;
      //       } else {
      //         button.display = true;
      //       }
      //     });
      //   }
      // });
    } else {
      //For add form
      this.Form.reset();
    }
  }

  ngOnChanges() {
    console.log('Multi Fooooooooooooooorm', this._multiFormArray);
  }

  addForm(card, button) {
    this.toggleCrossRefInfo();
    this.setCardAddMode(card);
    console.log('Add Form', this.selectedGroup);
    var formData = this.dynamicFormService.getFormData();
    formData.controls[this.formConfig["cardName"]].controls = this._multiFormArray.controls;

    formData.controls[this.formConfig["cardName"]].controls.push(this.selectedGroup);
    formData.controls[this.formConfig["cardName"]].value.push(this.selectedGroup.value);
    formData.value[this.formConfig["cardName"]] = formData.controls[this.formConfig["cardName"]].value;
    this.dynamicFormService.setFormData(formData);

    this.selectedGroup.markAsDirty();
    this.openForm(card, this.selectedGroup);
    this._multiFormArray.controls[this._multiFormArray.controls.length - 1].disable();
  }

  EnableFormFields(card, button) {
    this.toggleCrossRefInfo();
    this.setCardEditMode(card);
    if (this.formValues != null) {
      this._multiFormArray.controls.map((fGroup: FormGroup) => {
        fGroup.enable();
        fGroup.markAsDirty();
        // fGroup.controls. .map((control => FormControl)=> {
        //   control
        // })
      })

      // Object.keys(this.Form.controls).forEach(key => {
      //   if (card.cardName === key) {
      //     this.setCardEditMode(card);
      //     this.Form.controls[key].markAsDirty();
      //     this.Form.controls[key].enable();
      //     const formSubgroupControls = (this.Form.controls[key] as FormGroup).controls;
      //     Object.keys(formSubgroupControls).map(control => {
      //       formSubgroupControls[control].enable();
      //       formSubgroupControls[control].markAsDirty();

      //     })
      //   }
      // }
      // );
    }
  }


  setCardEditMode(card) {
    this.config.formCards = this.config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isEditing = true;
        c._isAddNew = false;
      }
      return c;
    })
  }

  setCardAddMode(card) {
    this.config.formCards = this.config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isAddNew = true;
        c._isEditing = false;
      }
      return c;
    })
  }

  isSelected(){
    var bool = true;
    this._multiFormArray.controls.map((form: any) => {
      if(form.isChecked){
        bool = false;
      }
    });
    return bool;
  }

  selectAll() {
    //console.log(selectAllChecked);
    // selectAllChecked = !selectAllChecked;
    if (this.selectAllChecked) {
      this._multiFormArray.controls.map((form: any) => {
        form.isChecked = true;
      });
    } else {
      this._multiFormArray.controls.map((form: any) => {
        form.isChecked = false;
      });
    }
  }

  setPrimary(event) {
    // const isAlreadyPrimary=  this._multiFormArray.controls.some((form:FormGroup)=>{
    //   return form.controls.isPrimary.value;
    // })
    // if(isAlreadyPrimary){

    // }
    //  if (event.checked) {
    this._multiFormArray.controls.map((form: FormGroup) => {
      form.controls.isPrimary.setValue(false);
    })

    this.selectedGroup.controls.isPrimary.setValue(event.checked);
    // } else if (!this.isAddnewSelected) {
    //   const previousPrimaryAdddressIndex = this.formValues[this.formConfig.cardName].findIndex(ele => ele.isPrimary);
    //   const prevPrimaryAddressformGroup = this._multiFormArray.controls[previousPrimaryAdddressIndex] as FormGroup;
    //   prevPrimaryAddressformGroup.controls.isPrimary.setValue(true);
    // }
    const formData = this.dynamicFormService.getFormData();
    formData.controls[this.formConfig["cardName"]].controls = this._multiFormArray.controls;
    formData.controls[this.formConfig["cardName"]].value = this._multiFormArray.value;
    // if(this.selectPrimaryChecked){
    //   formData.controls[this.formConfig["cardName"]].controls.map((form:any)=>{
    //       if(form.controls.isPrimary.value == true){
    //           this.isAlreadyPrimary = true;
    //       }
    //   });

    //   if(this.isAlreadyPrimary){
    //     //popup
    //     formData.controls[this.formConfig["cardName"]].controls.map((form:any)=>{

    //       form.value.isPrimary = false;
    //       form.controls.isPrimary.value = false;
    //       if(form.selected){
    //         form.value.isPrimary = true;
    //           form.controls.isPrimary.value = true;
    //       }
    //   });
    //   }
    //   else{
    //     formData.controls[this.formConfig["cardName"]].controls.map((form:any)=>{
    //         if(form.selected){
    //             form.value.isPrimary = true;
    //             form.controls.isPrimary.value = true;
    //         }
    //     });
    //   }
    // }
    // else{
    //   formData.controls[this.formConfig["cardName"]].controls.map((form:any)=>{
    //     if(form.selected){
    //       form.value.isPrimary = false;
    //       form.controls.isPrimary.value = false;
    //   }
    // });
    // }

    var arrValue = [];
    formData.controls[this.formConfig["cardName"]].controls.map((form: any) => {
      arrValue.push(form.value);
    });
    formData.value[this.formConfig["cardName"]] = arrValue;
    console.log('Set Primary');
    this.dynamicFormService.setFormData(formData);
  }

  getUpdatedvalue(evt) {
    console.log('Event Emit', evt);
  }

  openForm(card, locFormgroup) {
    card._isEditing = false;
    card._isAddNew = false;
    this.isAddnewSelected = false;
    //locFormgroup.value.addressLine1 + ',' + locFormgroup.value.addressLine2 + ',' + locFormgroup.value.addressLine3
    this._multiFormArray.controls.map((form: any) => {
      form.selected = false;
    });
    locFormgroup.selected = true;

    this.selectedGroup = locFormgroup;
    this.getAddress(card, this.selectedGroup);
    if (this.selectedGroup.controls.isPrimary.value == true) {
      this.selectPrimaryChecked = true;
    }
    else {
      this.selectPrimaryChecked = false;
    }

  }
}
