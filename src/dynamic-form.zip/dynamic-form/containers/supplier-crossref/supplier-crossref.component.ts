import { Component, OnInit, Input } from '@angular/core';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
//import data from '../../../../configs/forms/cross-supplier.json';
//import datalocation from '../../../../configs/forms/cross-location.json';

@Component({
  selector: 'app-supplier-crossref',
  templateUrl: './supplier-crossref.component.html',
  styleUrls: ['./supplier-crossref.component.scss']
})
export class SupplierCrossrefComponent implements OnInit {
  //inputColumns = ['Source Information', 'Source System ID', 'Supplier Legal Name', 'Year of Corporation', 'Ownership Type', 'Business Type', 'Business Criticality'];
  
  displayColumns: string[];
  displayData: any[];
  showTable: boolean;
   @Input() inputColumns;
   @Input() inputData;
  
  inputlocation;
  constructor() {
    //this.inputData = data;
    //this.inputlocation=datalocation;
  }

  _crossrefProperty: any;
  crossSupplier: any;

  @Input() set crossrefProperty(value) {
    this.setcrossrefProperty(value);
  };
  ngOnInit() {

    console.log(this.inputData);
    this.displayColumns = ['0'].concat(this.inputData.map(x => x["Source Information"].toString()));
    // console.log(this.displayColumns);
    if (this.inputColumns){
    this.displayData = this.inputColumns.map(x => this.formatInputRow(x));
  }
    this.showTable = true;
  }
  formatInputRow(row) {
    const output = {};

    output[0] = row;
    for (let i = 0; i < this.inputData.length; ++i) {
      if ('Source Information' == row) {
        output[this.inputData[i]["Source Information"]] = { title: this.inputData[i][row], color: this.inputData[i]['Source Color'] };

      } else {
        output[this.inputData[i]["Source Information"]] = this.inputData[i][row];
      }
    }
    console.log('output', output)
    return output;
  }
  setcrossrefProperty(crossrefProperty) {
    this._crossrefProperty = crossrefProperty;
  }
}


