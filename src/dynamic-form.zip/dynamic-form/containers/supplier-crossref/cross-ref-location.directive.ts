import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[crossrefLocation]',
})
export class CrossRefLocationDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}