import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupplierCrossrefComponent } from './supplier-crossref.component';

describe('SupplierCrossrefComponent', () => {
  let component: SupplierCrossrefComponent;
  let fixture: ComponentFixture<SupplierCrossrefComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupplierCrossrefComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupplierCrossrefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
