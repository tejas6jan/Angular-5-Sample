import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[crossrefIdentification]',
})
export class CrossRefIdentifictionDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}