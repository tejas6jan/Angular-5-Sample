import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[crossrefLoader]',
})
export class CrossRefLoaderDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}