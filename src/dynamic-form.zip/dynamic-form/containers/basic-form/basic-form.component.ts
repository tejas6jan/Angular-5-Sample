import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ComponentFactoryResolver } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CardConfig, CardContent, FormButton, FormConfig } from '../../form-config.model';
import { Subscription } from 'rxjs';
import { CrossRefLoaderDirective } from '../supplier-crossref/cross-ref-loader.directive';
import { CrossRefLocationDirective } from '../supplier-crossref/cross-ref-location.directive';
import { CrossRefIdentifictionDirective } from '../supplier-crossref/cross-ref-identification.directive';
import { DynamicFormService } from '../dynamic-form/dynamic-form.service';
import { ActionService } from '../../../../modules/supplier/action-buttons/action.service';
import { CustomValidation } from '../../validators/custom.validation';
import data from '../../../../configs/forms/cross-supplier.json';
import datalocation from '../../../../configs/forms/cross-location.json';
import dataIdentification from '../../../../configs/forms/cross-Identification.json';
import { SupplierCrossrefComponent } from '../supplier-crossref/supplier-crossref.component';
@Component({
  selector: 'app-basic-form',
  templateUrl: './basic-form.component.html',
  styleUrls: ['./basic-form.component.scss']
})
export class BasicFormComponent implements OnInit {
  subscription: Subscription;
  ShowCrossRef: boolean = true;
  componentRef: any;
  addressText: string = "";
  _basicForm: any;
  _formConfig: any;
  resetData: any;
  componentRefLocation: any;
  componentRefBasicDetails: any;
  componentRefIdentification: any;
  @ViewChild(CrossRefLoaderDirective, { static: false }) crossrefLoader: CrossRefLoaderDirective;
  @ViewChild(CrossRefLocationDirective, { static: false }) crossrefLocation: CrossRefLocationDirective;
  @ViewChild(CrossRefIdentifictionDirective, { static: false }) crossrefIdentification: CrossRefIdentifictionDirective;
  constructor(private dynamicFormService: DynamicFormService,
    private actionService: ActionService,
    private cv: CustomValidation,
    private componentFactoryResolver: ComponentFactoryResolver) { }
  @Input()
  public set basicForm(value: FormGroup) {
    this._basicForm = value;
  };
  @Input()
  public set formConfig(fconfig: CardConfig) {
    this._formConfig = fconfig;
  }
  @Input() formButton: FormButton;
  @Input() formMode: any;
  @Input()
  formValues: any = null;
  @Input()
  config: FormConfig;
  @Input() testText;
  Form: FormGroup;
  @Input() isAddnewSelected;
  @Input() selectPrimaryChecked;
  @Output() formChanges = new EventEmitter();
  @Output() newAddedData: EventEmitter<any> = new EventEmitter<object>();


  ngOnInit() {
    if (this.config) {
      this.intializeForm();
    }
  }

  intializeForm() {
    this.config.formCards = this.config.formCards.map(
      card => {
        if (card.cardName === this._formConfig.cardName && card.cardFormType.toLowerCase() === "basic") {
          card._isEditing = false;
          card._isAddNew = false;
          card._showingCrossRef = false;

        }
        return card;
      }
    )


    this.Form = this.dynamicFormService.createFormGroup(this.config, this.formValues);
    //this.resetData= Object.assign({}, this.Form);
    this.resetData = this.Form.getRawValue();
    this.dynamicFormService.setResetData(this.resetData);
    //this.resetData = this.Form;
    this.dynamicFormService.setFormData(this.Form);
    this.subscribeCrossRef();

  }

  subscribeCrossRef() {
    this.subscription = this.actionService.getSupplierCrossrefData().subscribe(data => {
      this.crossrefAll('basicdetails');
      this.crossrefAll('location');
      this.crossrefAll('identification');
    });
  }
  crossrefAll(crossrefProperty) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(SupplierCrossrefComponent);
    let viewContainerRef;
    if (crossrefProperty.toLowerCase() === 'basicdetails') {
      viewContainerRef = this.crossrefLoader.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefBasicDetails) {
        this.componentRefBasicDetails = !this.componentRefBasicDetails;
      } else {
        this.componentRefBasicDetails = viewContainerRef.createComponent(componentFactory);
        this.componentRefBasicDetails.instance.crossrefProperty = crossrefProperty;
        this.componentRefBasicDetails.instance.inputColumns = ['Source Information', 'Source System ID', 'Supplier Legal Name', 'Year of Corporation', 'Ownership Type', 'Business Type', 'Business Criticality'];
        this.componentRefBasicDetails.instance.inputData = data;
      }

    } else if (crossrefProperty.toLowerCase() === 'location') {
      //alert(crossrefProperty.toLowerCase());
      viewContainerRef = this.crossrefLocation.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefLocation) {
        this.componentRefLocation = !this.componentRefLocation;
      } else {
        this.componentRefLocation = viewContainerRef.createComponent(componentFactory);
        this.componentRefLocation.instance.crossrefProperty = crossrefProperty;
        this.componentRefLocation.instance.inputColumns = ['Source Information', 'Source System ID', 'Address line 1', 'Address line 2', 'Address line 3', 'City', 'State', 'Zip', 'Country'];
        this.componentRefLocation.instance.inputData = datalocation;
        //alert(viewContainerRef);
      }

    }
    else if (crossrefProperty.toLowerCase() === 'identification') {
      //alert(crossrefProperty.toLowerCase());
      viewContainerRef = this.crossrefIdentification.viewContainerRef;
      viewContainerRef.clear();
      if (this.componentRefIdentification) {
        this.componentRefIdentification = !this.componentRefIdentification;
      } else {
        this.componentRefIdentification = viewContainerRef.createComponent(componentFactory);
        this.componentRefIdentification.instance.crossrefProperty = crossrefProperty;
        this.componentRefIdentification.instance.inputColumns = ['Source Information', 'Source System ID', 'DUNS', 'EIN', 'VAT'];
        this.componentRefIdentification.instance.inputData = dataIdentification;
      }

      //alert(viewContainerRef);
    }
  }

  setCardAddMode(card) {
    this.config.formCards = this.config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isAddNew = true;
        c._isEditing = false;
      }
      return c;
    })
  }

  addForm(card, button) {
    this.toggleCrossRefInfo();
    this.setCardAddMode(card);
    console.log('Add Form', this._basicForm);
    var formData = this.dynamicFormService.getFormData();
    // formData.controls[this.formConfig["cardName"]].controls = this.multiFormArray.controls;

    // formData.controls[this.formConfig["cardName"]].controls.push(this.selectedGroup);
    // formData.controls[this.formConfig["cardName"]].value.push(this.selectedGroup.value);
    // formData.value[this.formConfig["cardName"]] = formData.controls[this.formConfig["cardName"]].value;
    // this.dynamicFormService.setFormData(formData);

    this._basicForm.markAsDirty();
    this.newAddedData.emit({ card: card, data: this._basicForm });
    //this.openForm(card, this._basicForm);
    this._basicForm.disable();
  }

  openForm(card, locFormgroup) {
    card._isEditing = false;
    card._isAddNew = false;
    this.isAddnewSelected = false;
    //locFormgroup.value.addressLine1 + ',' + locFormgroup.value.addressLine2 + ',' + locFormgroup.value.addressLine3
    // this.multiFormArray.controls.map((form: any) => {
    //   form.selected = false;
    // });
    locFormgroup.selected = true;

    this._basicForm = locFormgroup;
    this.getAddress(card, this._basicForm);
    if (this._basicForm.controls.isPrimary.value == true) {
      this.selectPrimaryChecked = true;
    }
    else {
      this.selectPrimaryChecked = false;
    }
  }

  getAddress(config, group) {
    if (!group || !config) { return ''; }
    this.addressText = "";
    if (config.cardName === "locations") {
      if (group.value.addressLine1 && group.value.addressLine1 != "") {
        this.addressText = group.value.addressLine1;
      }
      if (group.value.addressLine2 && group.value.addressLine2 != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.addressLine2;
        }
        else {
          this.addressText = group.value.addressLine2;
        }
      }
      if (group.value.country.name && group.value.country.name != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.country.name;
        }
        else {
          this.addressText = group.value.country.name;
        }
      }
    }
    if (config.cardName === "contacts") {
      if (group.value.firstName && group.value.firstName != "") {
        this.addressText = group.value.firstName;
      }
      if (group.value.middleName && group.value.middleName != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.middleName;
        }
        else {
          this.addressText = group.value.middleName;
        }
      }
      if (group.value.lastName && group.value.lastName != "") {
        if (this.addressText != "") {
          this.addressText = this.addressText + ' , ' + group.value.lastName;
        }
        else {
          this.addressText = group.value.lastName;
        }
      }
    }

    return this.addressText;
  }
  shouldDisplayButtons(card, button) {
    if (card._isEditing === true && (button.name === 'Save' || button.name === 'Cancel')) {
      return true;
    } else if ((card._isEditing === false && card._isAddNew === true) && (button.name === 'ADD')) {
      return true;
    } else if ((card._isEditing !== true && card._isAddNew === false) && button.name === 'Edit') {
      return true;
    } else {
      return false;
    }
    return false;
  }

  shouldDisableButton(card, button) {
    if ((button.name.toLowerCase() === 'save' || button.name.toLowerCase() === 'add') && !this._basicForm.valid) {
      return true;
    } else {
      return false;
    }
  }

  ResetForm(card, form) {
    this.dynamicFormService.setFormMode('view');
    card._isEditing = false;
    card._isAddNew = false;
    this.toggleCrossRefInfo();
    this.setCardEditCancelMode(card);
    if (this.formValues != null) {
      if (card.cardName === this._formConfig.cardName) {
        if (this.resetData[this._formConfig.cardName] && this.resetData[this._formConfig.cardName].length > 0) {
          this.resetData[this._formConfig.cardName].map((form) => {
            console.log(form);
            if (form.addressID === this._basicForm.value.addressID) {
              this._basicForm.setValue(form);
            }
          })
        } else {
          this._basicForm.setValue(this.resetData[this._formConfig.cardName]);
        }

        this._basicForm.disable();

        this.config.formButtons.forEach(button => {
          if (button.display == true) {
            button.display = false;
          } else {
            button.display = true;
          }
        });
      }
    }
    // if (this.formValues != null) {
    //   this.Form.reset(this.formValues);
    //   this._basicForm.disable();

    //   this.config.formButtons.forEach(button => {
    //     if (button.display == true) {
    //       button.display = false;
    //     } else {
    //       button.display = true;
    //     }
    //   });
    //   // Object.keys(this.Form.controls).forEach(key => {
    //   //   if (card.cardName === key) {
    //   //     this.setCardEditCancelMode(card);
    //   //     (this.Form.controls[key] as FormControl).disable();
    //   //     this.config.formButtons.forEach(button => {
    //   //       if (button.display == true) {
    //   //         button.display = false;
    //   //       } else {
    //   //         button.display = true;
    //   //       }
    //   //     });
    //   //   }
    //   // });
    // } else {
    //   //For add form
    //   this.Form.reset();
    // }
  }

  toggleCrossRefInfo() {
    this.ShowCrossRef = !this.ShowCrossRef;
    if (this.componentRefBasicDetails) {
      this.componentRefBasicDetails.destroy();
    }
    if (this.componentRefLocation) {
      this.componentRefLocation.destroy();
    }
    if (this.componentRefIdentification) {
      this.componentRefIdentification.destroy();
    }
    //this.ShowCrossRef = !this.ShowCrossRef;
  }
  setCardEditCancelMode(card) {
    this.config.formCards = this.config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isEditing = false;
      }
      return c;
    });
  }

  setCardEditMode(card) {
    this.config.formCards = this.config.formCards.map(c => {
      if (c.cardName === card.cardName) {
        c._isEditing = true;
      }
      return c;
    })
  }

  saveForm(card, button) {
    this.dynamicFormService.setFormMode('view');
    card._isEditing = false;
    this._basicForm.disable();
    var formData = this.dynamicFormService.getFormData();
    formData.controls[this._formConfig["cardName"]] = this._basicForm;
    formData.value[this._formConfig["cardName"]] = this._basicForm.value;
    this.dynamicFormService.setFormData(formData);
    //console.log('Updated Form Values : ',this.dynamicFormService.getFormData());
  }

  EnableFormFields(card, button) {
    this.dynamicFormService.setFormMode('add');
  this._basicForm.submitted = true;
    this.toggleCrossRefInfo();
    this.setCardEditMode(card);
   // if (this.formValues != null) {

      this._basicForm.enable();
      this._basicForm.markAsDirty();
   // }
      // Object.keys(this.Form.controls).forEach(key => {
      //   if (card.cardName === key) {
      //     this.setCardEditMode(card);
      //     this.Form.controls[key].markAsDirty();
      //     this.Form.controls[key].enable();
      //     const formSubgroupControls = (this.Form.controls[key] as FormGroup).controls;
      //     Object.keys(formSubgroupControls).map(control => {
      //       formSubgroupControls[control].enable();
      //       formSubgroupControls[control].markAsDirty();

      //     })
      //   }
      // }
      // );

  }

}
