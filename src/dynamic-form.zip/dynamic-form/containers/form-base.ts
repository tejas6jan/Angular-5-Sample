export class FormBase {
  shouldDisplayButtons(card, button) {
    if (card.isEditing === true && (button.Name === 'Save' || button.Name === 'Cancel')) {
      return true;
    } else if (card.isEditing !== true && button.Name === 'Edit') {
      return true;
    } else {
      return false;
    }
    return false;
  }
}
