import { LookupControlComponent } from './components/lookup-control/lookup-control.component';
import { ModalModule } from './components/modal/modal.module';
import { ModalComponent } from './components/modal/modal.component';
import { FormMultiselectComponent } from './components/form-multiselect/form-multiselect.component';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { DynamicFormComponent } from './containers/dynamic-form/dynamic-form.component';
import { FormInputComponent } from './components/form-input/form-input.component';
import { FormSelectComponent } from './components/form-select/form-select.component';
import { FormButtonComponent } from './components/form-button/form-button.component';
import { DynamicFieldDirective } from './components/dynamic-field/dynamic-field.directive';
//import { SupplierCrossrefComponent } from './containers/supplier-crossref/supplier-crossref.component'
//Remove unnecessary later(Start)
import { A11yModule } from '@angular/cdk/a11y';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { CdkTreeModule } from '@angular/cdk/tree';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatStepperModule } from '@angular/material/stepper';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSliderModule } from '@angular/material/slider';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTreeModule } from '@angular/material/tree';
import { SupplierCrossrefComponent } from './containers/supplier-crossref/supplier-crossref.component';
import { CrossRefLoaderDirective } from './containers/supplier-crossref/cross-ref-loader.directive';
import { CrossRefLocationDirective } from './containers/supplier-crossref/cross-ref-location.directive';
import { CrossRefIdentifictionDirective } from "./containers/supplier-crossref/cross-ref-identification.directive";
import { FormControlsService } from './form-controls.service';
import { DynamicFormService } from './containers/dynamic-form/dynamic-form.service';
import { BasicFormComponent } from './containers/basic-form/basic-form.component';
import { MultiFormComponent } from './containers/multi-form/multi-form.component';
import { MasterDataResolver } from './containers/dynamic-form/master-data.resolver.service';

@NgModule({
  declarations: [
    DynamicFormComponent,
    FormInputComponent,
    FormSelectComponent,
    FormMultiselectComponent,
    LookupControlComponent,
    FormButtonComponent,
    DynamicFieldDirective,
    SupplierCrossrefComponent,
    CrossRefLoaderDirective,
    CrossRefLocationDirective,
    CrossRefIdentifictionDirective,
    BasicFormComponent,
    MultiFormComponent,
    ModalComponent

  ],
  imports: [
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    ModalModule,
    //Remove unnecessary later(Start)
    A11yModule,
    CdkStepperModule,
    CdkTableModule,
    CdkTreeModule,
    DragDropModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    PortalModule,
    ScrollingModule
    //Remove unnecessary later(End)

  ],
  providers: [FormControlsService, DynamicFormService, MasterDataResolver],
  exports: [DynamicFormComponent],
  entryComponents: [
    ModalComponent,
    FormButtonComponent,
    FormInputComponent,
    FormMultiselectComponent,
    FormSelectComponent,
    SupplierCrossrefComponent,
    BasicFormComponent,
    LookupControlComponent
  ]
})
export class DynamicFormModule { }
