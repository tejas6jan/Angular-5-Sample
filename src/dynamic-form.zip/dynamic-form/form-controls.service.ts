import { Injectable, RendererFactory2, Renderer2 } from '@angular/core';
import { FormButton, CardContent } from './form-config.model';

@Injectable()
export class FormControlsService {
  renderer: Renderer2;
  constructor(rendererFactory: RendererFactory2) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  /**
     * @summary
     * Inner Function that helps createTitleButtons() to create each button;
     *
     * Sample output
     * <button class="mat-button" color="primary"
     *  (click)="this[fb.Onclick](card,fb)"
     *         [type]="fb.Type?fb.Type:''">
     *         <i *ngIf="fb.icon" class="icon small opener">
     *           <svg focusable="false">
     *             <use xmlns:xlink="http://www.w3.org/1999/xlink" attr.xlink:href="#{{fb.icon}}"></use>
     *           </svg>
     *         </i>
     * {{ fb.Label }}
     * </button>
     * @param buttonConfig
     */
  createButton(buttonConfig: FormButton) {
    const button = this.renderer.createElement('button');
    this.renderer.addClass(button, 'mat-button');
    this.renderer.setAttribute(button, 'color', 'primary');
    this.renderer.setAttribute(button, 'type', buttonConfig.type ? buttonConfig.type : 'button');
    this.renderer.listen(button, 'click', this[buttonConfig.onClick]);
    //    this.renderer.setAttribute({ color: 'primary', type: buttonConfig.type ? buttonConfig.type : 'button' });

    if (buttonConfig.icon) {
      const icon = this.renderer.createElement('i');
      this.renderer.addClass(icon, 'icon');
      this.renderer.addClass(icon, 'small');
      this.renderer.addClass(icon, 'opener');
      const iconSvg = this.renderer.createElement('svg', 'http://www.w3.org/2000/svg');
      this.renderer.setAttribute(iconSvg, 'focusable', 'false');
      const iconSvgXlink = this.renderer.createElement('use', 'http://www.w3.org/2000/svg');
      this.renderer.setAttribute(iconSvgXlink, 'xmlns:xlink', 'http://www.w3.org/1999/xlink');
      this.renderer.setAttribute(iconSvgXlink, 'xlink:href', '#' + buttonConfig.icon);
      iconSvg.appendChild(iconSvgXlink);
      icon.appendChild(iconSvg);
      button.appendChild(icon);
    }
    const buttonText = this.renderer.createText(buttonConfig.label);
    button.appendChild(buttonText);
    return button;
  }

  createInput(inputConfig: CardContent) {
    const divContainer = this.renderer.createElement('div');
    this.renderer.addClass(divContainer, 'dynamic-field');
    this.renderer.addClass(divContainer, 'form-input');

    const matFormField = this.renderer.createElement('mat-form-field');

    const input = this.renderer.createElement('input');
    this.renderer.addClass(input, 'mat-input');
    this.renderer.setAttribute(input, 'placeholder', inputConfig.label);
    if (inputConfig.validators && inputConfig.validators.find(v => v.validator.toLowerCase() === 'required')) {
      this.renderer.setAttribute(input, 'required', 'true');
    }

    const matError = this.renderer.createElement('mat-error');
    this.renderer.addClass(matError, 'mat-error');
    if (inputConfig.validators) {
      inputConfig.validators.map(v => {
        const strong = this.renderer.createElement('strong');
        const msg = this.renderer.createText(v.errorMsg);
        this.renderer.appendChild(strong, msg);
        this.renderer.appendChild(matError, strong);
      });
    }

    this.renderer.appendChild(matFormField, input);
    this.renderer.appendChild(matFormField, matError);
    this.renderer.appendChild(divContainer, matFormField);
    return divContainer;
  }
}
