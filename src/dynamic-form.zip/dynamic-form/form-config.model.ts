export interface FormConfig {
  formCards: CardConfig[];
  formButtons?: FormButton[];
}
export interface CardConfig {
  _showingCrossRef: boolean;
  _isEditing?: boolean;
  _isAddNew?: boolean;
  cardLabel: string;
  cardName: string;
  cardFormType: string;
  crossRefered: boolean;
  cardContent: CardContent[];
  cardButtons: FormButton[];
  validators: Validator[]
}
export interface CardContent {
  type: string;
  label: string;
  name: string;
  events?: {
    eventName?: string;
    eventFunction?: string;
  }[];
  validators?: Validator[];
  options?: {
    code: string;
    value: string;
  }[];
}
export interface FormButton {
  type?: string;
  label: string;
  name: string;
  onClick?: string;
  display?: boolean;
  icon?: string;
  params?: any;
}
export interface Validator {
  validator: string;
  errorMsg?: string;
  parameters?: any;
  isAsync: boolean;
}
