import { FormMultiselectComponent } from './../form-multiselect/form-multiselect.component';
import { ComponentFactoryResolver, Directive, Input, ViewContainerRef, OnInit, OnChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { FormButtonComponent } from '../form-button/form-button.component';
import { FormInputComponent } from '../form-input/form-input.component';
import { FormSelectComponent } from '../form-select/form-select.component';
import { CardContent } from '../../form-config.model';

const components = {
  button: FormButtonComponent,
  input: FormInputComponent,
  select: FormSelectComponent,
  multiselect: FormMultiselectComponent
};

@Directive({
  selector: '[appDynamicField]'
})
export class DynamicFieldDirective implements OnInit, OnChanges {
  _group: any;
  _config: any;
  initialized: boolean = false;
  @Input() set config(cval: CardContent) {
    this._config = cval;
  };
  @Input() set group(val: FormGroup) {
    this._group = val;
    this.setFormGroup();
  };
  @Input() service: any;
  @Input() formSubmitTracker;
  component;
  constructor(private resolver: ComponentFactoryResolver, private container: ViewContainerRef) { }

  ngOnInit() {
   // this.createField();
    this.setFormGroup();
  }
  createField() {
    const currentComponent = components[this._config.type];
    const factory = this.resolver.resolveComponentFactory<any>(currentComponent);
    this.component = this.container.createComponent(factory);
    this.component.instance.config = this._config;
    this.component.instance.service = this.service;
    this.component.instance.formSubmitTracker = this.formSubmitTracker;
    this.initialized = true;
    this.component.instance.group = this._group;
  }
  setFormGroup() {
    if (this._group) {
      if (this.component) { this.component.destroy(); }
      this.createField();
    }
  }
  ngOnChanges() {
    if (this.initialized) {
      this.component.instance.config = this._config;
      this.component.instance.group = this._group;
    }
  }

}
