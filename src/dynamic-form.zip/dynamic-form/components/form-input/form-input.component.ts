import { SupplierService } from './../../../../modules/supplier/service/supplier.service';
import { Component, OnInit, ElementRef, ViewChild, Input, Renderer2, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CardContent } from '../../form-config.model';
import { ErrorStateMatcher } from '@angular/material/core';
import { MyErrorStateMatcher } from './../../../../modules/supplier/model/myErrorStateMatcher';
import { DynamicFormService } from '../../containers/dynamic-form/dynamic-form.service';


@Component({
  selector: 'app-form-input',
  templateUrl: './form-input.component.html',
  styleUrls: ['./form-input.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FormInputComponent implements OnInit {
  formmode : any;
  config: CardContent;
  group: FormGroup;
  service: any;
  @Input() formSubmitTracker;
  isSubmitted: boolean;
  isRequiredField: boolean = false;
  @ViewChild('dyInput', { static: true }) elRef: ElementRef;

  EventFunctions = {
    'InputKeyUp': this.InputKeyUp
  };

  constructor(private renderer: Renderer2,
    private supService: SupplierService,
    private dynamicService : DynamicFormService) { }
  matcher = new MyErrorStateMatcher();
  ngOnInit() {
    /** Create Form Control */
    // this.isRequiredField = (this.config.validators != null &&
    //   this.config.validators.filter(v => v.validator.toLowerCase() === 'required').length > 0);

    // this.formSubmitTracker.subscribe(i => {
    //   this.isSubmitted = i;
    //   if (this.isSubmitted) {
    //     this.f.controls[this.config.name].markAsTouched();
    //   }
    // });
    this.formmode = this.dynamicService.getFormMode();

    if (this.config.events && this.config.events.length) {
      this.config.events.map(event => {
        if (event.eventName && event.eventFunction) {
          this.renderer.listen(this.elRef.nativeElement, event.eventName, this[event.eventFunction].bind(this));
        }
      });
      // for (let i = 0; i < this.config.events.length; i++) {
      //   this.elRef.nativeElement.addEventListener(this.config.events[i].eventName,
      //     this.EventFunctions[this.config.events[i].eventFunction].bind(this));
      //   //this.elRef.nativeElement.addEventListener('keyup', this[this.config.events[0].keyup].bind(this));
      // }
    }
  }

  // convenience getter for easy access to form fields
  get f() { return this.group; }

  InputKeyUp(event: any) {
    console.log(event);
    this.supService.InputKeyUp(event, this.config);
  }

  // InputKeyPress(event: any) {
  // }

  // InputKeyDown(event: any) {
  // }
  hasError(v) {
    return this.group.controls[this.config.name].invalid && this.group.controls[this.config.name].hasError(v.validator)
  }
}
