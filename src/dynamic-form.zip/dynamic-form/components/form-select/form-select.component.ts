import { Component, OnInit, Input, AfterViewInit, Renderer2, ElementRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { CardContent } from '../../form-config.model';
import { MyErrorStateMatcher } from './../../../../modules/supplier/model/myErrorStateMatcher';
import { DynamicFormService } from '../../containers/dynamic-form/dynamic-form.service';

@Component({
  selector: 'app-form-select',
  templateUrl: './form-select.component.html',
  styleUrls: ['./form-select.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FormSelectComponent implements OnInit {
  selectedVal: any;
  formmode: any;
  config: CardContent;
  group: FormGroup;
  @ViewChild('matSelect', { static: true }) matSelect: ElementRef;
  //  service: any;
  selected: any;
  // @Input()
  // formSubmitTracker;

  //  isSubmitted: boolean;

  // isRequiredField: boolean = false;


  matcher = new MyErrorStateMatcher();
  constructor(private renderer: Renderer2,
    private dynamicService : DynamicFormService) { }

  ngOnInit() {

    this.formmode = this.dynamicService.getFormMode();
   // this.selected = 'domain';
   // this.selectedVal = this.group.controls[this.config.name].value;
   // this.group.get(this.config.name).setValue(this.group.controls[this.config.name].value);
    // this.isRequiredField = (this.config.validators != null &&
    //   this.config.validators.filter(v => v.validator.toLowerCase() == "required").length > 0);

    // this.formSubmitTracker.subscribe(i => {
    //   this.isSubmitted = i;

    //   if (this.isSubmitted) {
    //     console.log('value', this.f.controls[this.config.name].value)
    //     this.group.controls[this.config.name].markAsTouched();
    //   }
    // });
    if (this.config.events && this.config.events.length) {
      this.config.events.map(event => {
        this.renderer.listen(this.matSelect.nativeElement, event.eventName, window[event.eventFunction]);
      });


    }
    console.log('fomrselc',this.group.controls[this.config.name]);
  }
  // ngAfterViewInit(): void {
  //   this.f.controls[this.config.name].setValue(this.f.controls[this.config.name].value.code);

  // }
  // convenience getter for easy access to form fields
  //get f() { return this.group; }
  hasError(v) {
    this.group.controls[this.config.name].invalid && this.group.controls[this.config.name].hasError(v.validator);
  }
  compareSelectedValue = (o1: { id, name }, o2: { id, name }) => o1.id === o2.id;

  getCodeValue(name){
    return this.dynamicService.getCodeValues(name);
  }
}
