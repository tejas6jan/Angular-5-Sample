import { Component, OnInit, ElementRef, ViewChild, Input, Renderer2, forwardRef } from '@angular/core';
import { FormGroup, FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CardContent } from '../../form-config.model';
import { ModalService } from '../modal/modal.service';
import { DynamicFormService } from '../../containers/dynamic-form/dynamic-form.service';

@Component({
  selector: 'app-lookup-control',
  templateUrl: './lookup-control.component.html',
  styleUrls: ['./lookup-control.component.scss'],
  providers:[{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(()=> LookupControlComponent),
    multi: true
  }]
})
export class LookupControlComponent implements OnInit,ControlValueAccessor {
  @Input() config: CardContent;
  @Input() group: FormGroup;
  onChanged : any = () =>{}
  onTouched : any = () =>{}
  value: any;
  groSelectedTitle: string;
  groTitleText : string;
  groData : any;
  groSelectedData : any;
  constructor(
    private dynamicService : DynamicFormService,private modalService: ModalService) {

  }
  ngOnInit() {
   // this.config.options = this.addSelectedValue(this.config.options);
   // this.groData = this.config.options;

    // this.groData =[{
    //   name: 'Fruit',
    //   id: 1,
    //   parentid : 0,
    //   selected : false,
    //   children: [
    //     {
    //       name: 'Apple',
    //       id: 2,
    //       parentid: 1,
    //       selected : false,
    //     children : [
    //       {
    //         name: 'Canada',
    //         id: 3,
    //         parentid: 2,
    //         selected : false
    //       },
    //       {
    //         name: 'Yellow',
    //         id: 4,
    //         parentid: 2,
    //         selected : false
    //       }
    //     ]
    //   },
    //     {
    //       name: 'Banana',
    //       id: 5,
    //       parentid: 1,
    //       selected : false
    //     },
    //     {
    //       name: 'Fruit loops',
    //       id: 6,
    //       parentid: 1,
    //       selected : false
    //     },
    //   ]
    // },
    //  {
    //   name: 'Vegetables',
    //   id: 7,
    //   parentid : 0,
    //   selected : false,
    //   children: [
    //     {
    //       name: 'Green',
    //       id: 8,
    //       parentid: 7,
    //       selected : false,
    //       children: [
    //         {
    //           name: 'Broccoli',
    //           id: 9,
    //           parentid: 8,
    //           selected : false,
    //         },
    //         {
    //           name: 'Brussel sprouts',
    //           id: 10,
    //           parentid: 8,
    //           selected : false,
    //           },
    //       ]
    //     }, {
    //       name: 'Orange',
    //       id: 11,
    //       parentid: 7,
    //       selected : false,
    //       children: [
    //         {
    //           name: 'Pumpkins',
    //           id: 12,
    //           parentid: 11,
    //           selected : false
    //         },
    //         {
    //           name: 'Carrots',
    //           id: 13,
    //           parentid: 11,
    //           selected : false
    //         }
    //       ]
    //     },
    //   ]
    // }];

    this.groSelectedData = this.group.controls[this.config.name].value;
    console.log('Check Config', this.config);
    // this.groSelectedData = [
    //   {
    //     name: "Red",
    //       selected: true,
    //       id: 3,
    //       parentid: 2
    //     },
    //     {
    //       name: "Fruit loops",
    //       selected: true,
    //       id: 6,
    //       parentid: 1
    //     },
    //     {
    //       name: "Broccoli",
    //       selected: true,
    //       id: 9,
    //       parentid: 8
    //     }
    // ];

    //this.selectedGroTreeData(this.groSelectedData);
    this.groTitleText =this.config.label;
  }

  addSelectedValue(obj: {[key: string]: any}): any {
    return Object.keys(obj).reduce<any>((accumulator, key) => {
        obj[key].selected = false;
      if (obj[key]["children"] != null) {
        if (Array.isArray(obj[key]["children"])) {
          this.addSelectedValue(obj[key]["children"]);
        }
      }
      return accumulator.concat(obj[key]);
    }, []);
  }



  writeValue(obj: any): void {
   // this.selectedGroTreeData(obj);
    this.value = obj;
    this.selectedGroTreeData(this.value);
  }
  registerOnChange(fn: any): void {
    this.onChanged = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    //throw new Error("Method not implemented.");
  }
  selectedGroTreeData(selectedData){
    console.log('Parent Selected Data:', selectedData);
    if(selectedData != null && selectedData && selectedData.length > 0){
      var countData = selectedData.length - 1;
      var firstData = selectedData[0].name;
      this.groSelectedTitle = firstData + ' + ' + countData + ' more';

    }
    else{
      this.groSelectedTitle = 'Select Data';
    }
    this.value = selectedData;
    this.onChanged(this.value);
    this.onTouched();
  }

    openModal(id: string) {
      this.modalService.open(id);
    }

    closeModal(id: string) {
        this.modalService.close(id);
    }

    getCodeValue(name){
      return this.dynamicService.getCodeValues(name);
    }

}


