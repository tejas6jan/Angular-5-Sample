import { Component, OnInit, Input, AfterViewInit, Renderer2, ElementRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CardContent } from '../../form-config.model';
import { DynamicFormService } from '../../containers/dynamic-form/dynamic-form.service';

@Component({
  selector: 'app-form-multiselect',
  templateUrl: './form-multiselect.component.html',
  styleUrls: ['./form-multiselect.component.scss'],

})
export class FormMultiselectComponent implements OnInit {
  selectedVal: any;

  config: CardContent;
  formmode: any;
  group: FormGroup;
  @ViewChild('matSelect', { static: true }) matSelect: ElementRef;
  //  service: any;
  selected: any;
  // @Input()
  // formSubmitTracker;

  //  isSubmitted: boolean;

  // isRequiredField: boolean = false;

  constructor(private renderer: Renderer2,
    private dynamicFormService: DynamicFormService) { }

  ngOnInit() {
    this.selected = 'domain';
    this.selectedVal = this.group.controls[this.config.name].value;
    this.formmode = this.dynamicFormService.getFormMode();
    // this.isRequiredField = (this.config.validators != null &&
    //   this.config.validators.filter(v => v.validator.toLowerCase() == "required").length > 0);

    // this.formSubmitTracker.subscribe(i => {
    //   this.isSubmitted = i;

    //   if (this.isSubmitted) {
    //     console.log('value', this.f.controls[this.config.name].value)
    //     this.group.controls[this.config.name].markAsTouched();
    //   }
    // });
    if (this.config.events && this.config.events.length) {
      this.config.events.map(event => {
        this.renderer.listen(this.matSelect.nativeElement, event.eventName, window[event.eventFunction]);
      });


    }
  }
  // ngAfterViewInit(): void {
  //   this.f.controls[this.config.name].setValue(this.f.controls[this.config.name].value.code);

  // }
  // convenience getter for easy access to form fields
  //get f() { return this.group; }


  hasError(v) {
    this.group.controls[this.config.name].invalid && this.group.controls[this.config.name].hasError(v.validator)
  }
  onchange(value) {
    this.group.controls[this.config.name].setValue(value);
  }
}
