import { locations, basicDetails } from './../model/supplier.model';
import { Component, OnInit } from '@angular/core';
import FormConfig from '../../../configs/forms/add-supplier.json';
import { SupplierService } from '../service/supplier.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Breadcrumb, Master } from 'src/shared/components/page-level-header/page-level-header.model.js';
import { AlertService } from '../../../shared/Alert/AlertService';
import { FormGroup, FormArray } from '@angular/forms';
import { DynamicFormService } from '../../../shared/dynamic-form/containers/dynamic-form/dynamic-form.service';
@Component({
  selector: 'app-add-supplier',
  templateUrl: './add-supplier.component.html',
  styleUrls: ['./add-supplier.component.scss']
})
export class AddSupplierComponent implements OnInit {
  CodeValue : any;
  Config = FormConfig;
  ServiceRef: any;
  pageTitle: string;
  breadCrumb: Breadcrumb[] = [];
  actions: Master[] = [];
  moreMenu: Master[] = [];
  supplierForm: FormGroup;
  resetObj : any;

  constructor(
    private supplierSvr: SupplierService,
    private alertService: AlertService,
    private dynamicFormService: DynamicFormService,
    private router: Router) {
    this.ServiceRef = supplierSvr;
    this.pageTitle = 'Create Supplier Profile';
    this.breadCrumb = [{
      href: '/',
      title: 'Home'
    },
    {
      href: '/',
      title: 'Overview'
    },
    {
      href: '/',
      title: 'Profile'
    }];

  }

  ngOnInit() {
    this.resetObj =
    {"basicDetails":{"supplierID":null,"supplierLegalName":"","parentCompany":null,"doingBusinessAs":"","yearOfIncorporation":"","formerlyKnownAs":"","annualRevenue":0,"numberofEmployees":0,"createdOn":"3/17/2020 8:07:37 PM","businessType":{"id":0,"name":""},"ownershipType":{},"categories":[],"organizationEntities":[],"regions":[],"status":{"id":0,"name":""},"supplierStatus":{"id":0,"name":""},"relationType":{"id":0,"name":""},"businessCriticality":{"id":0,"name":""},"riskType":{"id":0,"name":""}},"locations":[],"identifications":[],"contacts":[],"socialMedia":[]};
  }

  convertObjToArr(mapData) {
    var convertArr = [];
    if (Object.keys(mapData).length > 0) {
      var keyArr = Object.keys(mapData);
      for (var i = 0; i < keyArr.length; i++) {
        var keyVal = Object.values(mapData)[i];
        if (keyVal && keyVal != "") {
          var myObj = {} as any;
          myObj.name = keyArr[i];
          myObj.value = keyVal;
          convertArr.push(myObj);
        }
      }
    }
    return convertArr;
  }

  saveObj() {
    //if((this.supplierForm.controls["basicDetails"] as FormGroup).controls.supplierLegalName.invalid){
    //  (this.supplierForm.controls["basicDetails"] as FormGroup).markAllAsTouched();

   // }
   //(this.supplierForm.controls["basicDetails"] as FormGroup).controls.businessType.markAsTouched();
    if (this.supplierForm.invalid) {
      this.supplierForm.markAllAsTouched();
      return;
    }
    var convertedIdentification = this.convertObjToArr(this.supplierForm.controls.identifications.value);
    var convertedSocialMedia = this.convertObjToArr(this.supplierForm.controls.socialMedia.value);
    var postSupplierModel = this.dynamicFormService.generatePostSupplierData(this.supplierForm, convertedIdentification, convertedSocialMedia);
    console.log('Post Supplier Data:', postSupplierModel);
    // this.supplierSvr.EditSupplier(postSupplierModel, 10);

    this.supplierSvr.AddSupplier(postSupplierModel)
      .subscribe(responseData => {
        if (responseData['isSuccess']) {
          this.supplierForm.reset(this.resetObj);
          this.alertService.success('Supplier Added Successfully.');
          // this.supplierForm.markAsPristine();
          // this.supplierForm.updateValueAndValidity();
          // this.supplierForm.reset();

          let returnedSupplierID = responseData['returnValue'];
          this.redirectTo('supplier/view-supplier/' + returnedSupplierID);
        }
      },errorData=>{
          console.log(errorData);
      });
  }

  getMasterCodeValue(){
    this.supplierSvr.MasterDataCodeValue().subscribe(data => {
        this.CodeValue = data['returnValue'];
        this.dynamicFormService.setCodeValues(this.CodeValue);
    });
  }

  closeObj(){
    //this.dynamicFormService.createFormGroup(this.Config, undefined);
    //  this.supplierForm.markAsPristine();
    //  this.supplierForm.markAsDirty();
    //  this.supplierForm.updateValueAndValidity();
    this.dynamicFormService.setIsAddCancel(true);
    this.supplierForm.reset(this.resetObj);
  }

  FormSubmitted(formData) {
    // if(this.resetObj == undefined){
    //   this.resetObj = formData;
    // }
    this.supplierForm = formData;
    //this.supplierForm.markAsPristine();
    //this.supplierForm.updateValueAndValidity();
    console.log('formData on submit', formData);
    if (formData.invalid) {
      return;
    }
    let httpBody = {};
    Object.keys(formData.value).map(ele => {
      httpBody = { ...httpBody, ...formData.value[ele] };
    });
    // this.supplierSvr.AddSupplier(httpBody)

    //   .subscribe(responseData => {

    //     if (responseData['isSuccess']) {
    //       this.alertService.success('Supplier added successfully.');
    //     }
    //     else {
    //       alert('Some error occured.');
    //     }
    //     //console.log(responseData);
    //     this.router.navigate(['supplier/dashboard']);
    //   });

  }

  redirectTo(url:string) {

    this.router.navigate([url]);
  }

}
